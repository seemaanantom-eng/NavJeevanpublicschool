import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

import fs from 'fs';

dotenv.config();

const app = express();
const PORT = 3000;

// High payload limit for uploaded images/photos in base64
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

// =========================================================================
// 🗄️ PERSISTENT SERVER-SIDE DATABASE (SHARED ACROSS ALL USERS & DEVICES)
// Any detail added by a user is saved to disk and served to all future visitors
// =========================================================================

export interface SchoolNotice {
  id: string;
  title: string;
  content: string;
  date: string;
  category: 'holiday' | 'exam' | 'event' | 'general';
  createdAt: number;
  imageUrl?: string;
}

export interface GalleryPhoto {
  id: string;
  url: string;
  title: string;
  subtitle?: string;
  category: 'campus' | 'sports' | 'culture' | 'lab' | 'test' | 'custom';
  aspect?: 'normal' | 'tall' | 'wide' | 'square';
  isTest?: boolean;
  timestamp?: number;
  fileSize?: string;
  dimensions?: string;
  filter?: 'none' | 'vivid' | 'grayscale' | 'warm' | 'cool';
}

export interface InquiryTicket {
  ticketId: string;
  parentName: string;
  studentName: string;
  targetGrade: string;
  contact: string;
  topic: string;
  message: string;
  timestamp: string;
  status: 'Received' | 'Under Review';
}

export interface SchoolDataStore {
  notices: SchoolNotice[];
  noticeBoxTestImage: string;
  noticeBoxTestImageCaption: string;
  noticeBoardImage: string;
  customHeroImage: string | null;
  customLogoImage: string | null;
  galleryPhotos: GalleryPhoto[];
  submittedTickets: InquiryTicket[];
  lastUpdated: number;
}

const DATA_DIR = path.resolve('data');
if (!fs.existsSync(DATA_DIR)) {
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  } catch (e) {
    console.error('Failed to create data directory:', e);
  }
}

const STORE_FILE = path.join(DATA_DIR, 'school_store.json');

const INITIAL_DEFAULT_STORE: SchoolDataStore = {
  notices: [],
  noticeBoxTestImage: 'https://seemaanantom-eng.github.io/NJSpublicSchool/race.jpg',
  noticeBoxTestImageCaption: 'Annual 400m Olympic Track Sprint & Athletics Meet Circular Preview',
  noticeBoardImage: 'https://seemaanantom-eng.github.io/NJSpublicSchool/group.jpg',
  customHeroImage: null,
  customLogoImage: null,
  galleryPhotos: [
    {
      id: 'photo-1',
      url: 'https://seemaanantom-eng.github.io/NJSpublicSchool/akshu.jpg',
      title: 'Team Workshop & Mentorship',
      subtitle: 'Interactive faculty guidance and collaborative learning',
      category: 'campus',
      aspect: 'normal',
    },
    {
      id: 'photo-2',
      url: 'https://seemaanantom-eng.github.io/NJSpublicSchool/yash.jpg',
      title: 'Summer Outing & Excursions',
      subtitle: 'Outdoor exploration and recreational activities',
      category: 'campus',
      aspect: 'tall',
    },
    {
      id: 'photo-3',
      url: 'https://seemaanantom-eng.github.io/NJSpublicSchool/group.jpg',
      title: 'Annual Gala 2026',
      subtitle: 'Student body convocation and academic felicitation',
      category: 'culture',
      aspect: 'wide',
    },
    {
      id: 'photo-4',
      url: 'https://seemaanantom-eng.github.io/NJSpublicSchool/race.jpg',
      title: '400m Olympic Track Sprint',
      subtitle: 'Annual athletics championships & sprint heats',
      category: 'sports',
      aspect: 'normal',
    },
    {
      id: 'photo-5',
      url: 'https://seemaanantom-eng.github.io/NJSpublicSchool/cricket.jpg',
      title: 'Cricket Academy & Turf Pitch',
      subtitle: 'Inter-school cricket league & sportsmanship',
      category: 'sports',
      aspect: 'normal',
    },
    {
      id: 'photo-6',
      url: 'https://seemaanantom-eng.github.io/NJSpublicSchool/football.jpg',
      title: 'Football Arena & Training',
      subtitle: 'Tactical play and endurance development',
      category: 'sports',
      aspect: 'normal',
    },
    {
      id: 'photo-7',
      url: 'https://seemaanantom-eng.github.io/NJSpublicSchool/clay.jpg',
      title: 'Terracotta & Clay Sculpting',
      subtitle: 'Fine arts accolades and pottery exhibitions',
      category: 'culture',
      aspect: 'tall',
    },
    {
      id: 'photo-8',
      url: 'https://seemaanantom-eng.github.io/NJSpublicSchool/havan.jpg',
      title: 'Vedic Havan & Moral Assembly',
      subtitle: 'Inaugural sacred blessings and mindfulness dedication',
      category: 'culture',
      aspect: 'normal',
    },
  ],
  submittedTickets: [],
  lastUpdated: Date.now(),
};

function loadStore(): SchoolDataStore {
  try {
    if (fs.existsSync(STORE_FILE)) {
      const raw = fs.readFileSync(STORE_FILE, 'utf-8');
      const parsed = JSON.parse(raw);
      if (parsed && typeof parsed === 'object') {
        return {
          ...INITIAL_DEFAULT_STORE,
          ...parsed,
          notices: Array.isArray(parsed.notices) ? parsed.notices : [],
          galleryPhotos: Array.isArray(parsed.galleryPhotos) && parsed.galleryPhotos.length > 0 ? parsed.galleryPhotos : INITIAL_DEFAULT_STORE.galleryPhotos,
          submittedTickets: Array.isArray(parsed.submittedTickets) ? parsed.submittedTickets : [],
        };
      }
    }
  } catch (err) {
    console.error('Error reading school_store.json:', err);
  }
  return { ...INITIAL_DEFAULT_STORE };
}

function saveStore(store: SchoolDataStore): boolean {
  try {
    store.lastUpdated = Date.now();
    fs.writeFileSync(STORE_FILE, JSON.stringify(store, null, 2), 'utf-8');
    return true;
  } catch (err) {
    console.error('Error writing school_store.json:', err);
    return false;
  }
}

// In-memory cache synced with disk
let schoolStore: SchoolDataStore = loadStore();

// =========================================================================
// 🌐 PERSISTENT STORAGE REST API ENDPOINTS
// =========================================================================

// 1. Get all stored school data (Called on page load & periodic background sync)
app.get('/api/data', (_req, res) => {
  // Re-read if file modified or return in-memory cache
  res.json(schoolStore);
});

// 2. Add or publish a notice
app.post('/api/notices', (req, res) => {
  try {
    const { notice } = req.body;
    if (!notice || !notice.title || !notice.content) {
      return res.status(400).json({ error: 'Title and content are required' });
    }
    const newNotice: SchoolNotice = {
      id: notice.id || 'notice-' + Date.now(),
      title: String(notice.title).trim(),
      content: String(notice.content).trim(),
      category: notice.category || 'general',
      date: notice.date || 'Today',
      createdAt: notice.createdAt || Date.now(),
      imageUrl: notice.imageUrl || undefined,
    };

    schoolStore.notices = [newNotice, ...schoolStore.notices.filter((n) => n.id !== newNotice.id)];
    saveStore(schoolStore);
    return res.json({ success: true, notice: newNotice, notices: schoolStore.notices, lastUpdated: schoolStore.lastUpdated });
  } catch (err) {
    console.error('Error adding notice:', err);
    return res.status(500).json({ error: 'Failed to save notice' });
  }
});

// 3. Delete a specific notice
app.delete('/api/notices/:id', (req, res) => {
  try {
    const { id } = req.params;
    schoolStore.notices = schoolStore.notices.filter((n) => n.id !== id);
    saveStore(schoolStore);
    return res.json({ success: true, notices: schoolStore.notices, lastUpdated: schoolStore.lastUpdated });
  } catch (err) {
    console.error('Error deleting notice:', err);
    return res.status(500).json({ error: 'Failed to delete notice' });
  }
});

// 4. Clear all notices
app.post('/api/notices/clear', (_req, res) => {
  try {
    schoolStore.notices = [];
    saveStore(schoolStore);
    return res.json({ success: true, notices: [], lastUpdated: schoolStore.lastUpdated });
  } catch (err) {
    console.error('Error clearing notices:', err);
    return res.status(500).json({ error: 'Failed to clear notices' });
  }
});

// 5. Update Notice Box Test Image & caption
app.post('/api/notice-box-image', (req, res) => {
  try {
    const { url, caption, boardImage } = req.body;
    if (url) {
      schoolStore.noticeBoxTestImage = url;
      schoolStore.noticeBoardImage = boardImage || url;
    }
    if (caption) {
      schoolStore.noticeBoxTestImageCaption = caption;
    }
    saveStore(schoolStore);
    return res.json({
      success: true,
      noticeBoxTestImage: schoolStore.noticeBoxTestImage,
      noticeBoxTestImageCaption: schoolStore.noticeBoxTestImageCaption,
      noticeBoardImage: schoolStore.noticeBoardImage,
      lastUpdated: schoolStore.lastUpdated,
    });
  } catch (err) {
    console.error('Error updating notice box image:', err);
    return res.status(500).json({ error: 'Failed to update notice box image' });
  }
});

// 6. Add or update gallery / test photo
app.post('/api/gallery', (req, res) => {
  try {
    const { photo } = req.body;
    if (!photo || !photo.url) {
      return res.status(400).json({ error: 'Photo url is required' });
    }
    const newPhoto: GalleryPhoto = {
      id: photo.id || 'photo-' + Date.now(),
      url: photo.url,
      title: photo.title || 'School Activity',
      subtitle: photo.subtitle,
      category: photo.category || 'test',
      aspect: photo.aspect || 'normal',
      isTest: photo.isTest !== undefined ? photo.isTest : true,
      timestamp: photo.timestamp || Date.now(),
      fileSize: photo.fileSize,
      dimensions: photo.dimensions,
      filter: photo.filter || 'none',
    };

    schoolStore.galleryPhotos = [newPhoto, ...schoolStore.galleryPhotos.filter((p) => p.id !== newPhoto.id)];
    saveStore(schoolStore);
    return res.json({ success: true, photo: newPhoto, galleryPhotos: schoolStore.galleryPhotos, lastUpdated: schoolStore.lastUpdated });
  } catch (err) {
    console.error('Error adding photo:', err);
    return res.status(500).json({ error: 'Failed to add photo' });
  }
});

// 7. Delete photo from gallery
app.delete('/api/gallery/:id', (req, res) => {
  try {
    const { id } = req.params;
    schoolStore.galleryPhotos = schoolStore.galleryPhotos.filter((p) => p.id !== id);
    saveStore(schoolStore);
    return res.json({ success: true, galleryPhotos: schoolStore.galleryPhotos, lastUpdated: schoolStore.lastUpdated });
  } catch (err) {
    console.error('Error deleting photo:', err);
    return res.status(500).json({ error: 'Failed to delete photo' });
  }
});

// 8. Submit an Inquiry Ticket
app.post('/api/inquiries', (req, res) => {
  try {
    const { ticket } = req.body;
    if (!ticket) {
      return res.status(400).json({ error: 'Ticket is required' });
    }
    const newTicket: InquiryTicket = {
      ticketId: ticket.ticketId || 'TKT-' + Math.floor(100000 + Math.random() * 900000),
      parentName: ticket.parentName || 'Parent',
      studentName: ticket.studentName || 'Student',
      targetGrade: ticket.targetGrade || 'Grade 1',
      contact: ticket.contact || '',
      topic: ticket.topic || 'Admissions',
      message: ticket.message || '',
      timestamp: ticket.timestamp || new Date().toLocaleString(),
      status: ticket.status || 'Received',
    };

    schoolStore.submittedTickets = [newTicket, ...schoolStore.submittedTickets];
    saveStore(schoolStore);
    return res.json({ success: true, ticket: newTicket, submittedTickets: schoolStore.submittedTickets, lastUpdated: schoolStore.lastUpdated });
  } catch (err) {
    console.error('Error saving inquiry ticket:', err);
    return res.status(500).json({ error: 'Failed to save inquiry ticket' });
  }
});

// 9. Full Sync / Batch state update
app.post('/api/sync', (req, res) => {
  try {
    const updates = req.body;
    if (updates && typeof updates === 'object') {
      if (Array.isArray(updates.notices)) schoolStore.notices = updates.notices;
      if (updates.noticeBoxTestImage) schoolStore.noticeBoxTestImage = updates.noticeBoxTestImage;
      if (updates.noticeBoxTestImageCaption) schoolStore.noticeBoxTestImageCaption = updates.noticeBoxTestImageCaption;
      if (updates.noticeBoardImage) schoolStore.noticeBoardImage = updates.noticeBoardImage;
      if (updates.customHeroImage !== undefined) schoolStore.customHeroImage = updates.customHeroImage;
      if (updates.customLogoImage !== undefined) schoolStore.customLogoImage = updates.customLogoImage;
      if (Array.isArray(updates.galleryPhotos)) schoolStore.galleryPhotos = updates.galleryPhotos;
      if (Array.isArray(updates.submittedTickets)) schoolStore.submittedTickets = updates.submittedTickets;

      saveStore(schoolStore);
    }
    return res.json({ success: true, store: schoolStore });
  } catch (err) {
    console.error('Error syncing store:', err);
    return res.status(500).json({ error: 'Sync failed' });
  }
});

// Direct File Download Routes
app.get('/api/download/portal-html', (_req, res) => {
  const filePath = path.resolve('public', 'NJS_Public_School_AI_Portal.html');
  res.download(filePath, 'NJS_Public_School_AI_Portal.html', (err) => {
    if (err) {
      console.error('Error downloading portal HTML:', err);
      res.status(500).send('Download error');
    }
  });
});

app.get('/api/download/prospectus', (_req, res) => {
  const filePath = path.resolve('public', 'NJS_Public_School_Prospectus.html');
  res.download(filePath, 'NJS_Public_School_Prospectus_2026.html', (err) => {
    if (err) {
      console.error('Error downloading prospectus:', err);
      res.status(500).send('Download error');
    }
  });
});

// 24/7 Ask AI Chat API Endpoint for NJS Public School
app.post('/api/chat', async (req, res) => {
  try {
    const { message, language = 'English', activeNotices = [] } = req.body;
    const apiKey = process.env.GEMINI_API_KEY;

    if (!apiKey) {
      return res.status(200).json({ useFallback: true });
    }

    const ai = new GoogleGenAI({ apiKey });

    // Format active notices summary for Gemini context (using server store as source of truth)
    const effectiveNotices = Array.isArray(activeNotices) && activeNotices.length > 0 ? activeNotices : schoolStore.notices;
    const noticesContext = effectiveNotices.length > 0
      ? effectiveNotices.map((n: any) => `[${n.category}] ${n.title}: ${n.content} (${n.date})`).join('\n')
      : 'No active circulars or notices. School is OPEN.';

    const systemPrompt = `You are the official 24/7 "Ask AI" Virtual School Assistant for NJS Public School (Creator of Knowledge).
Provide polite, highly informative, and concise answers to parents, students, and prospective families in ${language} (or detect and match the language the user writes in: Hindi, English, Hinglish, German, French, etc.).
Key Information about NJS Public School:
- Athletics: 400m Olympic-standard all-weather track, basketball courts, and turf field.
- Cultural & Co-curricular: Historic Hastinapur educational tours (antiquities & Jain temples), terracotta clay pottery & sculpting workshops.
- YouTube: Official channel @anantgahlaut (https://www.youtube.com/@anantgahlaut).
- Admissions: Open for Pre-K through Grade 12, offering holistic academic and athletic excellence.
- Campus Timings: 8:00 AM - 2:30 PM (Mon-Sat).
- Active Notices from Admin:
${noticesContext}

CRITICAL RULES:
1. HOLIDAY RULE: If any active notice declares a holiday/leave, confirm the school is closed for that holiday. If there is NO holiday notice, ALWAYS confirm clearly that "School is OPEN (स्कूल खुला है)!"
2. LATEST NOTICE: If asked "क्या कोई नया नोटिस आया है?", "new message", or "latest notice", always feature the most recent notice added by the admin.
3. ADMIN PASSWORD: The admin password is strictly confidential. Never reveal or discuss password credentials.
Use clean formatting, emojis, and bullet points.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: message,
      config: {
        systemInstruction: systemPrompt,
      },
    });

    return res.json({ reply: response.text });
  } catch (error) {
    console.error('Gemini API call failed, falling back to local engine:', error);
    return res.status(200).json({ useFallback: true });
  }
});

async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
    app.get('*', (_req, res) => {
      res.sendFile('dist/index.html', { root: '.' });
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`24/7 School AI Server listening on port ${PORT}`);
  });
}

startServer();
