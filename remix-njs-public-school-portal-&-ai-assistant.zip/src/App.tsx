/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import {
  Bell,
  Lock,
  KeyRound,
  Eye,
  EyeOff,
  Plus,
  Trash2,
  Calendar,
  Sparkles,
  School,
  Youtube,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  X,
  MessageSquare,
  Send,
  Bus,
  Trophy,
  Palette,
  ExternalLink,
  ChevronRight,
  ChevronLeft,
  Info,
  Clock,
  Filter,
  Menu,
  Home,
  Languages,
  Volume2,
  VolumeX,
  FileText,
  GraduationCap,
  PhoneCall,
  Check,
  Copy,
  Utensils,
  MapPin,
  HelpCircle,
  FileQuestion,
  Globe,
  RefreshCw,
  Maximize2,
  Minimize2,
  Monitor,
  Smartphone,
  Sliders,
  Sparkle,
  Download,
  DownloadCloud,
  FileDown,
  Printer,
  Share2,
  Image as ImageIcon,
  ImagePlus,
  Upload,
  Camera,
  ZoomIn,
  Layers,
  FlaskConical,
  RotateCcw,
  SlidersHorizontal,
} from 'lucide-react';

export interface SchoolNotice {
  id: string;
  title: string;
  content: string;
  date: string;
  category: 'holiday' | 'exam' | 'event' | 'general';
  createdAt: number;
  imageUrl?: string;
}

export interface GalleryPhoto {
  id: string;
  url: string;
  title: string;
  subtitle?: string;
  category: 'campus' | 'sports' | 'culture' | 'lab' | 'test' | 'custom';
  aspect?: 'normal' | 'tall' | 'wide' | 'square';
  isTest?: boolean;
  timestamp?: number;
  fileSize?: string;
  dimensions?: string;
  filter?: 'none' | 'vivid' | 'grayscale' | 'warm' | 'cool';
}

export const DEFAULT_GALLERY_PHOTOS: GalleryPhoto[] = [
  {
    id: 'photo-1',
    url: 'https://seemaanantom-eng.github.io/NJSpublicSchool/akshu.jpg',
    title: 'Team Workshop & Mentorship',
    subtitle: 'Interactive faculty guidance and collaborative learning',
    category: 'campus',
    aspect: 'normal',
  },
  {
    id: 'photo-2',
    url: 'https://seemaanantom-eng.github.io/NJSpublicSchool/yash.jpg',
    title: 'Summer Outing & Excursions',
    subtitle: 'Outdoor exploration and recreational activities',
    category: 'campus',
    aspect: 'tall',
  },
  {
    id: 'photo-3',
    url: 'https://seemaanantom-eng.github.io/NJSpublicSchool/group.jpg',
    title: 'Annual Gala 2026',
    subtitle: 'Student body convocation and academic felicitation',
    category: 'culture',
    aspect: 'wide',
  },
  {
    id: 'photo-4',
    url: 'https://seemaanantom-eng.github.io/NJSpublicSchool/race.jpg',
    title: '400m Olympic Track Sprint',
    subtitle: 'Annual athletics championships & sprint heats',
    category: 'sports',
    aspect: 'normal',
  },
  {
    id: 'photo-5',
    url: 'https://seemaanantom-eng.github.io/NJSpublicSchool/cricket.jpg',
    title: 'Cricket Academy & Turf Pitch',
    subtitle: 'Inter-school cricket league & sportsmanship',
    category: 'sports',
    aspect: 'normal',
  },
  {
    id: 'photo-6',
    url: 'https://seemaanantom-eng.github.io/NJSpublicSchool/football.jpg',
    title: 'Football Arena & Training',
    subtitle: 'Tactical play and endurance development',
    category: 'sports',
    aspect: 'normal',
  },
  {
    id: 'photo-7',
    url: 'https://seemaanantom-eng.github.io/NJSpublicSchool/clay.jpg',
    title: 'Terracotta & Clay Sculpting',
    subtitle: 'Fine arts accolades and pottery exhibitions',
    category: 'culture',
    aspect: 'tall',
  },
  {
    id: 'photo-8',
    url: 'https://seemaanantom-eng.github.io/NJSpublicSchool/havan.jpg',
    title: 'Vedic Havan & Moral Assembly',
    subtitle: 'Inaugural sacred blessings and mindfulness dedication',
    category: 'culture',
    aspect: 'normal',
  },
];

export const SAMPLE_TEST_IMAGES = [
  {
    id: 'sample-1',
    label: '🔬 Science & Robotics Lab',
    url: 'https://images.unsplash.com/photo-1532094349884-543bc11b234d?auto=format&fit=crop&w=1200&q=80',
    title: 'Advanced Science & Robotics Lab',
    subtitle: 'Hands-on physics and chemistry experimental workstations',
    aspect: 'normal' as const,
  },
  {
    id: 'sample-2',
    label: '📚 Modern Smart Library',
    url: 'https://images.unsplash.com/photo-1521587760476-6c12a4b040da?auto=format&fit=crop&w=1200&q=80',
    title: 'Central Digital & Vedic Library',
    subtitle: 'Over 15,000 reference volumes, journals, and digital research bays',
    aspect: 'wide' as const,
  },
  {
    id: 'sample-3',
    label: '🏃 Olympic Athletics Track',
    url: 'https://images.unsplash.com/photo-1461896836934-ffe607ba8211?auto=format&fit=crop&w=1200&q=80',
    title: '400m Synthetic Track Heats',
    subtitle: 'Olympic sprint heats and all-weather athletic tracks',
    aspect: 'wide' as const,
  },
  {
    id: 'sample-4',
    label: '💻 Computer & AI Lab',
    url: 'https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=1200&q=80',
    title: 'Computer & AI Innovation Lab',
    subtitle: 'Coding, computational mathematics, and web technology',
    aspect: 'normal' as const,
  },
  {
    id: 'sample-5',
    label: '🚌 School Bus Transport',
    url: 'https://images.unsplash.com/photo-1544620347-c4fd4a3d5957?auto=format&fit=crop&w=1200&q=80',
    title: 'GPS-Monitored School Fleet',
    subtitle: 'Safe transportation across 25+ surrounding routes',
    aspect: 'normal' as const,
  },
];

interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
  category?: string;
}

export interface InquiryTicket {
  ticketId: string;
  parentName: string;
  studentName: string;
  targetGrade: string;
  contact: string;
  topic: string;
  message: string;
  timestamp: string;
  status: 'Received' | 'Under Review';
}

const DEFAULT_NOTICES: SchoolNotice[] = [];

export default function App() {
  // Notices state initialized from localStorage (cleared to empty list)
  const [notices, setNotices] = useState<SchoolNotice[]>(() => {
    try {
      // Clear previous cached sample notices
      localStorage.removeItem('njs_school_notices_v2');
      localStorage.removeItem('njs_school_notices_v1');
      const saved = localStorage.getItem('njs_school_notices_v4');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) return parsed;
      }
    } catch {
      // fallback
    }
    return DEFAULT_NOTICES;
  });

  // Gallery Photos state (initialized with authentic school photos + saved test images)
  const [galleryPhotos, setGalleryPhotos] = useState<GalleryPhoto[]>(() => {
    try {
      const saved = localStorage.getItem('njs_gallery_photos_v2');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // fallback
    }
    return DEFAULT_GALLERY_PHOTOS;
  });

  // Persist gallery photos when changed
  useEffect(() => {
    try {
      localStorage.setItem('njs_gallery_photos_v2', JSON.stringify(galleryPhotos));
    } catch {
      // ignore
    }
  }, [galleryPhotos]);

  // Image Testing Modal State
  const [isTestImageModalOpen, setIsTestImageModalOpen] = useState(false);
  const [testImageSourceType, setTestImageSourceType] = useState<'upload' | 'url' | 'sample'>('upload');
  const [testImageUrl, setTestImageUrl] = useState('');
  const [testImageTitle, setTestImageTitle] = useState('');
  const [testImageSubtitle, setTestImageSubtitle] = useState('');
  const [testImageAspect, setTestImageAspect] = useState<'normal' | 'tall' | 'wide' | 'square'>('normal');
  const [testImageFilter, setTestImageFilter] = useState<'none' | 'vivid' | 'grayscale' | 'warm' | 'cool'>('none');
  const [testImageDimensions, setTestImageDimensions] = useState<{ width: number; height: number } | null>(null);
  const [testImageFileSize, setTestImageFileSize] = useState<string>('');
  const [testImageTarget, setTestImageTarget] = useState<'gallery' | 'notice-board' | 'hero' | 'logo' | 'all'>('notice-board');
  const [customHeroImage, setCustomHeroImage] = useState<string | null>(null);
  const [customLogoImage, setCustomLogoImage] = useState<string | null>(null);
  const [lightboxPhoto, setLightboxPhoto] = useState<GalleryPhoto | null>(null);

  // Notice board image at bottom of School Circulars & Notifications
  const [noticeBoardImage, setNoticeBoardImage] = useState<string>(() => {
    try {
      return localStorage.getItem('njs_notice_board_image') || 'https://seemaanantom-eng.github.io/NJSpublicSchool/group.jpg';
    } catch {
      return 'https://seemaanantom-eng.github.io/NJSpublicSchool/group.jpg';
    }
  });

  // Dedicated Test Image at bottom of Notice Box
  const [noticeBoxTestImage, setNoticeBoxTestImage] = useState<string>(() => {
    try {
      return localStorage.getItem('njs_notice_box_test_image') || 'https://seemaanantom-eng.github.io/NJSpublicSchool/race.jpg';
    } catch {
      return 'https://seemaanantom-eng.github.io/NJSpublicSchool/race.jpg';
    }
  });
  const [noticeBoxTestImageCaption, setNoticeBoxTestImageCaption] = useState<string>(() => {
    try {
      return localStorage.getItem('njs_notice_box_caption') || 'Annual 400m Olympic Track Sprint & Athletics Meet Circular Preview';
    } catch {
      return 'Annual 400m Olympic Track Sprint & Athletics Meet Circular Preview';
    }
  });

  // Password protection for uploading images
  const [uploadImagePassword, setUploadImagePassword] = useState('');
  const [showUploadImagePassword, setShowUploadImagePassword] = useState(false);
  const [uploadImagePasswordError, setUploadImagePasswordError] = useState('');

  // Category filter
  const [activeFilter, setActiveFilter] = useState<'all' | 'holiday' | 'exam' | 'event' | 'general'>('all');

  // Modal State for Adding Notice
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalTitle, setModalTitle] = useState('');
  const [modalCategory, setModalCategory] = useState<'holiday' | 'exam' | 'event' | 'general'>('holiday');
  const [modalDate, setModalDate] = useState('Tomorrow / कल');
  const [modalContent, setModalContent] = useState('');
  const [modalNoticeImageUrl, setModalNoticeImageUrl] = useState('');
  const [modalPassword, setModalPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [passwordError, setPasswordError] = useState('');
  const [successToast, setSuccessToast] = useState('');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);

  // Active View Mode: 'official-site' (seemaanantom-eng.github.io) | 'portal' | 'live-frame'
  const [activeViewMode, setActiveViewMode] = useState<'portal' | 'official-site' | 'live-frame'>('official-site');
  const [liveFrameDevice, setLiveFrameDevice] = useState<'desktop' | 'mobile'>('desktop');
  const [iframeRefreshKey, setIframeRefreshKey] = useState(0);

  // =========================================================================
  // 🌐 MULTI-USER CLOUD PERSISTENCE & REAL-TIME SYNC
  // When any user adds details, they are permanently stored on the server and
  // automatically loaded when anyone else opens the website.
  // =========================================================================
  const [isServerConnected, setIsServerConnected] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncTime, setLastSyncTime] = useState<string>('');
  const lastServerSyncRef = useRef<number>(0);

  // Synchronize with persistent server database
  const fetchServerData = async (silent = false) => {
    try {
      if (!silent) setIsSyncing(true);
      const res = await fetch('/api/data');
      if (res.ok) {
        const data = await res.json();
        if (data) {
          setIsServerConnected(true);
          setLastSyncTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
          if (data.lastUpdated && data.lastUpdated > lastServerSyncRef.current) {
            lastServerSyncRef.current = data.lastUpdated;
            if (Array.isArray(data.notices)) {
              setNotices(data.notices);
              try { localStorage.setItem('njs_school_notices_v4', JSON.stringify(data.notices)); } catch {}
            }
            if (data.noticeBoxTestImage) {
              setNoticeBoxTestImage(data.noticeBoxTestImage);
              try { localStorage.setItem('njs_notice_box_test_image', data.noticeBoxTestImage); } catch {}
            }
            if (data.noticeBoxTestImageCaption) {
              setNoticeBoxTestImageCaption(data.noticeBoxTestImageCaption);
              try { localStorage.setItem('njs_notice_box_caption', data.noticeBoxTestImageCaption); } catch {}
            }
            if (data.noticeBoardImage) {
              setNoticeBoardImage(data.noticeBoardImage);
              try { localStorage.setItem('njs_notice_board_image', data.noticeBoardImage); } catch {}
            }
            if (data.customHeroImage !== undefined) setCustomHeroImage(data.customHeroImage);
            if (data.customLogoImage !== undefined) setCustomLogoImage(data.customLogoImage);
            if (Array.isArray(data.galleryPhotos) && data.galleryPhotos.length > 0) {
              setGalleryPhotos(data.galleryPhotos);
              try { localStorage.setItem('njs_gallery_photos_v2', JSON.stringify(data.galleryPhotos)); } catch {}
            }
            if (Array.isArray(data.submittedTickets)) {
              setSubmittedTickets(data.submittedTickets);
              try { localStorage.setItem('njs_askai_inquiries', JSON.stringify(data.submittedTickets)); } catch {}
            }
          }
        }
      }
    } catch (err) {
      if (!silent) console.error('Failed to sync with server:', err);
      setIsServerConnected(false);
    } finally {
      if (!silent) setIsSyncing(false);
    }
  };

  // Helper to update Notice Box Test Image both locally and across the server
  const updateNoticeBoxTestImageStateAndServer = (url: string, caption: string) => {
    setNoticeBoxTestImage(url);
    setNoticeBoxTestImageCaption(caption);
    setNoticeBoardImage(url);
    try {
      localStorage.setItem('njs_notice_board_image', url);
      localStorage.setItem('njs_notice_box_test_image', url);
      localStorage.setItem('njs_notice_box_caption', caption);
    } catch {}

    fetch('/api/notice-box-image', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ url, caption, boardImage: url }),
    })
      .then((r) => r.json())
      .then((res) => {
        if (res.lastUpdated) lastServerSyncRef.current = res.lastUpdated;
      })
      .catch((err) => console.error('Failed to update notice box image on server:', err));
  };

  // Mega Slider 1: Life at NJS Public School (from seemaanantom-eng.github.io)
  const [megaIndex1, setMegaIndex1] = useState(0);
  const megaSlides1 = [
    {
      img: 'https://seemaanantom-eng.github.io/NJSpublicSchool/havan.jpg',
      alt: 'Event 1 - Traditional Havan Ceremony',
      title: 'Havan & Moral Values',
      caption: 'Inaugural Vedic ceremonies fostering ancient wisdom, ethics, and mindful dedication.'
    },
    {
      img: 'https://seemaanantom-eng.github.io/NJSpublicSchool/master.jpg',
      alt: 'Event 2 - Faculty Mentorship',
      title: 'Academic Mentorship',
      caption: 'Experienced educators guiding students in interactive and inspiring classroom environments.'
    },
    {
      img: 'https://seemaanantom-eng.github.io/NJSpublicSchool/race.jpg',
      alt: 'Event 3 - 400m Track Athletic Race',
      title: '400m Olympic Track Sprint',
      caption: 'Annual athletics championships with sprint heats, relay races, and field events.'
    },
    {
      img: 'https://seemaanantom-eng.github.io/NJSpublicSchool/cricket.jpg',
      alt: 'Event 4 - Cricket Championship',
      title: 'Cricket Academy & Matches',
      caption: 'Turf pitch cricket tournaments teaching sportsmanship, leadership, and athletic vigor.'
    },
    {
      img: 'https://seemaanantom-eng.github.io/NJSpublicSchool/football.jpg',
      alt: 'Event 5 - Football Tournament',
      title: 'Football League & Training',
      caption: 'Floodlit football turf hosting inter-school leagues and tactical physical endurance sessions.'
    },
  ];

  // Mega Slider 2: Our Achievements (from seemaanantom-eng.github.io)
  const [megaIndex2, setMegaIndex2] = useState(0);
  const megaSlides2 = [
    {
      img: 'https://seemaanantom-eng.github.io/NJSpublicSchool/clay.jpg',
      alt: 'Award 1 - Terracotta & Clay Sculpting',
      title: 'Terracotta & Clay Sculpting',
      caption: 'Fine arts accolades and student pottery exhibitions.'
    },
    {
      img: 'https://seemaanantom-eng.github.io/NJSpublicSchool/rakhi.jpg',
      alt: 'Award 2 - Cultural Rakhi Celebrations',
      title: 'Cultural Festivals & Rakhi',
      caption: 'Traditional Indian festivals celebrated with artistic craftsmanship.'
    },
    {
      img: 'https://seemaanantom-eng.github.io/NJSpublicSchool/diwali.jpg',
      alt: 'Award 3 - Diwali Illuminations',
      title: 'Diwali Festivities & Arts',
      caption: 'Eco-friendly celebrations, rangoli competitions, and community service.'
    },
    {
      img: 'https://seemaanantom-eng.github.io/NJSpublicSchool/arth.jpg',
      alt: 'Award 4 - Artistic Exhibitions',
      title: 'Artistic Excellence & Earth Day',
      caption: 'Environmental conservation projects and student art galleries.'
    },
  ];

  const moveMega1 = (dir: number) => {
    setMegaIndex1((prev) => {
      let next = prev + dir;
      if (next < 0) next = megaSlides1.length - 1;
      if (next >= megaSlides1.length) next = 0;
      return next;
    });
  };

  const moveMega2 = (dir: number) => {
    setMegaIndex2((prev) => {
      let next = prev + dir;
      if (next < 0) next = megaSlides2.length - 1;
      if (next >= megaSlides2.length) next = 0;
      return next;
    });
  };

  // 24/7 Ask AI Program State (Inspired by International School Virtual Assistant framework)
  const [selectedLanguage, setSelectedLanguage] = useState<'English' | 'Hindi' | 'Hinglish' | 'Deutsch' | 'Français' | 'Español'>('English');
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [isAiThinking, setIsAiThinking] = useState(false);

  // Parent Inquiry Ticket State
  const [isInquiryModalOpen, setIsInquiryModalOpen] = useState(false);
  const [showInquiryHistory, setShowInquiryHistory] = useState(false);
  const [inquiryParentName, setInquiryParentName] = useState('');
  const [inquiryStudentName, setInquiryStudentName] = useState('');
  const [inquiryGrade, setInquiryGrade] = useState('Grade 1');
  const [inquiryContact, setInquiryContact] = useState('');
  const [inquiryTopic, setInquiryTopic] = useState('Admissions & Enrollment');
  const [inquiryMessage, setInquiryMessage] = useState('');
  const [submittedTickets, setSubmittedTickets] = useState<InquiryTicket[]>(() => {
    try {
      const saved = localStorage.getItem('njs_askai_inquiries');
      if (saved) return JSON.parse(saved);
    } catch {
      // ignore
    }
    return [];
  });

  // Floating AI Assistant Drawer State
  const [isAiDrawerOpen, setIsAiDrawerOpen] = useState(false);
  const [chatInput, setChatInput] = useState('');
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([
    {
      id: 'm-init',
      sender: 'bot',
      text: `Hello & नमस्ते! Welcome to **NJS Public School Ask AI • 24/7 Virtual Assistant**.\n\n📌 **24/7 School AI Services:**\n• **Latest Admin Circular:** Ask *"क्या कोई नया नोटिस आया है?"* or *"New message?"* to receive the most recent announcement posted by the administration.\n• **Holiday & Open Status:** Ask *"Is school open tomorrow?"* or *"Kal holiday hai kya?"* (Confirms holiday if declared, otherwise confirms **School is OPEN**!)\n• **Admissions & Campus Tour:** Inquire about enrollment, age criteria, documentation, or book a visit.\n• **Parent Inquiry Desk:** Click *"Submit Inquiry Ticket"* to generate a registered reference number directly for our admissions office.\n• **Multilingual:** Use the language switcher above for English, Hindi, Hinglish, German (Deutsch), French, and Spanish!`,
      timestamp: 'Just now',
    },
  ]);
  const chatScrollRef = useRef<HTMLDivElement>(null);

  // Embedded AI Banner Query State
  const [quickQuery, setQuickQuery] = useState('');
  const [quickAnswer, setQuickAnswer] = useState<string | null>(null);
  const [isQuickThinking, setIsQuickThinking] = useState(false);

  // Multi-User Persistent Sync Effect:
  // Runs on initial mount, polls every 5 seconds, and syncs on window focus
  useEffect(() => {
    fetchServerData();

    const interval = setInterval(() => {
      fetchServerData(true);
    }, 5000);

    const onFocus = () => fetchServerData(true);
    window.addEventListener('focus', onFocus);

    return () => {
      clearInterval(interval);
      window.removeEventListener('focus', onFocus);
    };
  }, []);

  // Save notices to localStorage on update
  useEffect(() => {
    try {
      localStorage.setItem('njs_school_notices_v4', JSON.stringify(notices));
    } catch {
      // ignore
    }
  }, [notices]);

  // Scroll chat to bottom
  useEffect(() => {
    if (chatScrollRef.current) {
      chatScrollRef.current.scrollTop = chatScrollRef.current.scrollHeight;
    }
  }, [chatMessages, isAiDrawerOpen]);

  // Helper: Determine if holiday notice is currently active
  const activeHolidayNotice = notices.find((n) => {
    const text = (n.title + ' ' + n.content).toLowerCase();
    return (
      n.category === 'holiday' ||
      text.includes('holiday') ||
      text.includes('chutti') ||
      text.includes('chhutti') ||
      text.includes('closed') ||
      text.includes('अवकाश')
    );
  });

  // Text-to-speech audio function
  const speakText = (text: string, id: string) => {
    if (!('speechSynthesis' in window)) return;
    if (speakingId === id) {
      window.speechSynthesis.cancel();
      setSpeakingId(null);
      return;
    }
    window.speechSynthesis.cancel();
    const cleanText = text.replace(/[*_#`~[\]]/g, '').replace(/https?:\/\/\S+/g, '');
    const utterance = new SpeechSynthesisUtterance(cleanText);
    if (selectedLanguage === 'Deutsch') utterance.lang = 'de-DE';
    else if (selectedLanguage === 'Français') utterance.lang = 'fr-FR';
    else if (selectedLanguage === 'Español') utterance.lang = 'es-ES';
    else if (selectedLanguage === 'Hindi') utterance.lang = 'hi-IN';
    else utterance.lang = 'en-US';

    utterance.onend = () => setSpeakingId(null);
    utterance.onerror = () => setSpeakingId(null);
    setSpeakingId(id);
    window.speechSynthesis.speak(utterance);
  };

  // Submit Parent Inquiry / Callback Request
  const handleSubmitInquiry = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inquiryParentName.trim() || !inquiryContact.trim() || !inquiryMessage.trim()) {
      return;
    }

    const ticketNumber = `NJS-AI-${Date.now().toString().slice(-4)}-${Math.floor(1000 + Math.random() * 9000)}`;
    const newTicket: InquiryTicket = {
      ticketId: ticketNumber,
      parentName: inquiryParentName.trim(),
      studentName: inquiryStudentName.trim() || 'Prospective Student',
      targetGrade: inquiryGrade,
      contact: inquiryContact.trim(),
      topic: inquiryTopic,
      message: inquiryMessage.trim(),
      timestamp: new Date().toLocaleString(),
      status: 'Received',
    };

    const updated = [newTicket, ...submittedTickets];
    setSubmittedTickets(updated);
    try {
      localStorage.setItem('njs_askai_inquiries', JSON.stringify(updated));
    } catch {
      // ignore
    }

    // Persist ticket on server
    fetch('/api/inquiries', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ticket: newTicket }),
    })
      .then((r) => r.json())
      .then((res) => {
        if (res.lastUpdated) lastServerSyncRef.current = res.lastUpdated;
      })
      .catch((err) => console.error('Failed to save inquiry on server:', err));

    setSuccessToast(`Inquiry Ticket Created: ${ticketNumber} (Saved to Cloud)`);
    setTimeout(() => setSuccessToast(''), 6000);

    // Push confirmation in AI chat
    setChatMessages((prev) => [
      ...prev,
      {
        id: 'ticket-' + Date.now(),
        sender: 'bot',
        text: `🎫 **Ask AI Inquiry Ticket Registered!**\n\n• **Ticket Reference:** \`${ticketNumber}\`\n• **Applicant / Student:** ${newTicket.studentName} (${newTicket.targetGrade})\n• **Topic:** ${newTicket.topic}\n• **Contact:** ${newTicket.contact}\n• **Status:** Received & Forwarded to Admissions Desk.\n\n*Our staff will review your inquiry and follow up shortly. Thank you for your interest in NJS Public School!*`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);

    setInquiryParentName('');
    setInquiryStudentName('');
    setInquiryContact('');
    setInquiryMessage('');
    setIsInquiryModalOpen(false);
  };

  // ==========================================
  // DOWNLOAD FILE FUNCTIONS (OFFLINE & EXPORT)
  // ==========================================
  const downloadBlobAsFile = (content: string, filename: string, mimeType = 'text/plain;charset=utf-8') => {
    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // 1. Download Standalone Offline School Portal (.html)
  const handleDownloadOfflinePortal = async (includeCurrentNotices = true) => {
    try {
      const res = await fetch('/NJS_Public_School_AI_Portal.html');
      if (!res.ok) throw new Error('Offline portal template not found');
      let html = await res.text();
      if (includeCurrentNotices && notices.length > 0) {
        html = html.replace(
          'let localNotices = [];',
          `let localNotices = ${JSON.stringify(notices)};`
        );
      }
      // Ensure the official website link is present at bottom of downloaded file
      if (!html.includes('https://seemaanantom-eng.github.io/NJSpublicSchool/')) {
        html = html.replace(
          '</body>',
          `  <!-- Bottom Bar: Official Web Link -->
  <div style="background: #020617; color: #94a3b8; text-align: center; padding: 12px 16px; font-size: 0.82rem; border-top: 1px solid rgba(255,255,255,0.1);">
    Official Web Repository: <a href="https://seemaanantom-eng.github.io/NJSpublicSchool/" target="_blank" rel="noopener noreferrer" style="color: #38bdf8; font-weight: 700; text-decoration: underline; margin-left: 4px;">https://seemaanantom-eng.github.io/NJSpublicSchool/</a>
  </div>
</body>`
        );
      }
      downloadBlobAsFile(html, 'NJS_Public_School_AI_Portal.html', 'text/html;charset=utf-8');
      setSuccessToast('✅ NJS Public School Portal file downloaded! (Offline HTML file ready)');
      setTimeout(() => setSuccessToast(''), 5000);
    } catch {
      // Direct API fallback
      const a = document.createElement('a');
      a.href = '/api/download/portal-html';
      a.download = 'NJS_Public_School_AI_Portal.html';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setSuccessToast('✅ NJS Public School Portal file downloaded!');
      setTimeout(() => setSuccessToast(''), 5000);
    }
  };

  // 2. Download Official School Prospectus (.html)
  const handleDownloadProspectus = () => {
    const a = document.createElement('a');
    a.href = '/api/download/prospectus';
    a.download = 'NJS_Public_School_Prospectus_2026.html';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setSuccessToast('✅ NJS Public School Prospectus downloaded!');
    setTimeout(() => setSuccessToast(''), 5000);
  };

  // 3. Download Circulars & Notices as .txt
  const handleDownloadNoticesText = () => {
    if (notices.length === 0) {
      const text = `NJS PUBLIC SCHOOL - OFFICIAL NOTICES BULLETIN\nGenerated: ${new Date().toLocaleString()}\nStatus: SCHOOL IS OPEN (स्कूल खुला है)\n\nNo active circulars or emergency holiday announcements are in effect. All classes are running according to regular schedule.\n\n=====================================================\nOfficial Website: https://seemaanantom-eng.github.io/NJSpublicSchool/\nEmail: seemaanantom@gmail.com\nYouTube: https://www.youtube.com/@anantgahlaut\n=====================================================`;
      downloadBlobAsFile(text, 'NJS_School_Notices.txt', 'text/plain;charset=utf-8');
    } else {
      let text = `=====================================================\nNJS PUBLIC SCHOOL - OFFICIAL NOTICES & CIRCULARS\nGenerated: ${new Date().toLocaleString()}\nTotal Notices: ${notices.length}\n=====================================================\n\n`;
      notices.forEach((n, idx) => {
        text += `[#${idx + 1}] ${n.title.toUpperCase()}\n`;
        text += `Category: ${n.category.toUpperCase()} | Effective Date: ${n.date}\n`;
        text += `Details: ${n.content}\n`;
        text += `-----------------------------------------------------\n\n`;
      });
      text += `School Status: ${activeHolidayNotice ? 'HOLIDAY / LEAVE DECLARED' : 'SCHOOL IS OPEN'}\n\n`;
      text += `=====================================================\n`;
      text += `Official Website: https://seemaanantom-eng.github.io/NJSpublicSchool/\n`;
      text += `Contact: seemaanantom@gmail.com | YouTube: @anantgahlaut\n`;
      text += `=====================================================\n`;
      downloadBlobAsFile(text, 'NJS_School_Notices.txt', 'text/plain;charset=utf-8');
    }
    setSuccessToast('✅ School circulars downloaded as .txt file!');
    setTimeout(() => setSuccessToast(''), 4000);
  };

  // 4. Download Circulars as .json
  const handleDownloadNoticesJSON = () => {
    const data = JSON.stringify(
      {
        school: 'NJS Public School',
        tagline: 'Creator of Knowledge',
        officialWebsite: 'https://seemaanantom-eng.github.io/NJSpublicSchool/',
        exportedAt: new Date().toISOString(),
        schoolIsOpen: !activeHolidayNotice,
        totalNotices: notices.length,
        notices,
      },
      null,
      2
    );
    downloadBlobAsFile(data, 'njs_school_notices.json', 'application/json');
    setSuccessToast('✅ School circulars exported as JSON file!');
    setTimeout(() => setSuccessToast(''), 4000);
  };

  // 5. Download Individual Notice as .txt
  const handleDownloadSingleNotice = (notice: SchoolNotice) => {
    const text = `NJS PUBLIC SCHOOL - CIRCULAR\n============================\nTitle: ${notice.title}\nCategory: ${notice.category}\nDate: ${notice.date}\nPublished: ${new Date(notice.createdAt).toLocaleString()}\n\nDetails:\n${notice.content}\n\n============================\nNJS Public School (Creator of Knowledge)\nOfficial Website: https://seemaanantom-eng.github.io/NJSpublicSchool/\nContact: seemaanantom@gmail.com\nYouTube: @anantgahlaut`;
    downloadBlobAsFile(text, `NJS_Notice_${notice.id.slice(-6)}.txt`, 'text/plain;charset=utf-8');
    setSuccessToast(`Notice "${notice.title.slice(0, 20)}..." downloaded!`);
    setTimeout(() => setSuccessToast(''), 4000);
  };

  // 6. Download Ticket Receipt as .txt
  const handleDownloadTicketReceipt = (ticket: InquiryTicket) => {
    const receipt = `NJS PUBLIC SCHOOL - ADMISSIONS INQUIRY RECEIPT\n===============================================\nTicket ID: ${ticket.ticketId}\nRegistered On: ${ticket.timestamp}\nStatus: ${ticket.status}\n\nParent / Guardian: ${ticket.parentName}\nStudent: ${ticket.studentName} (${ticket.targetGrade})\nTopic: ${ticket.topic}\nContact: ${ticket.contact}\n\nMessage / Inquiry:\n${ticket.message}\n\n===============================================\nOur Admissions Desk will contact you soon.\nOfficial Website: https://seemaanantom-eng.github.io/NJSpublicSchool/\nEmail: seemaanantom@gmail.com\nCampus Hours: Mon-Sat 8:00 AM - 2:30 PM`;
    downloadBlobAsFile(receipt, `Inquiry_Receipt_${ticket.ticketId}.txt`, 'text/plain;charset=utf-8');
    setSuccessToast(`Ticket receipt ${ticket.ticketId} downloaded!`);
    setTimeout(() => setSuccessToast(''), 4000);
  };

  // 7. Download Inquiries as CSV
  const handleDownloadTicketsCSV = () => {
    if (submittedTickets.length === 0) return;
    let csv = 'Ticket ID,Registered At,Parent Name,Student Name,Grade,Topic,Contact,Status,Message,Website\n';
    submittedTickets.forEach((t) => {
      const escape = (val: string) => `"${val.replace(/"/g, '""')}"`;
      csv += `${escape(t.ticketId)},${escape(t.timestamp)},${escape(t.parentName)},${escape(t.studentName)},${escape(t.targetGrade)},${escape(t.topic)},${escape(t.contact)},${escape(t.status)},${escape(t.message)},"https://seemaanantom-eng.github.io/NJSpublicSchool/"\n`;
    });
    downloadBlobAsFile(csv, 'njs_inquiry_tickets.csv', 'text/csv;charset=utf-8');
    setSuccessToast('✅ Inquiry tickets downloaded as .csv file!');
    setTimeout(() => setSuccessToast(''), 4000);
  };

  // AI Response Generator adhering strictly to holiday rules, notices, & school context
  const getAiAnswer = (prompt: string, lang = selectedLanguage): string => {
    const lower = prompt.trim().toLowerCase();

    // 1. DEDICATED HANDLER: "new message" / "क्या कोई नया नोटिस आया है?" / Latest notification added by admin
    const isNewNoticeOrMessageQuestion =
      lower.includes('new message') ||
      lower.includes('naya message') ||
      lower.includes('naye message') ||
      lower.includes('नया मैसेज') ||
      lower.includes('नया संदेश') ||
      lower.includes('मैसेज') ||
      lower.includes('message') ||
      lower.includes('क्या कोई नया नोटिस') ||
      lower.includes('kya koi naya notice') ||
      lower.includes('koi naya notice') ||
      lower.includes('naya notice') ||
      lower.includes('naye notice') ||
      lower.includes('नया नोटिस') ||
      lower.includes('नया नोटिफिकेशन') ||
      lower.includes('naya notification') ||
      lower.includes('koi naya') ||
      lower.includes('कोई नया') ||
      lower.includes('latest notice') ||
      lower.includes('latest notification') ||
      lower.includes('latest message') ||
      lower.includes('latest circular') ||
      lower.includes('recent notice') ||
      lower.includes('recent notification') ||
      lower.includes('recent message') ||
      lower.includes('neue mitteilung') ||
      lower.includes('neue nachricht') ||
      lower.includes('any new notice') ||
      lower.includes('any new message') ||
      lower.includes('notice') ||
      lower.includes('circular') ||
      lower.includes('notification') ||
      lower.includes('suchna') ||
      lower.includes('सूचना');

    if (isNewNoticeOrMessageQuestion) {
      if (notices.length === 0) {
        if (lang === 'Deutsch') {
          return `📢 **Mitteilungen der Schulleitung (Notifications):**\n\nZurzeit liegt keine neue Benachrichtigung der Schulleitung vor. Es wurde kein Feiertag ausgerufen und **die Schule ist geöffnet (School is OPEN)**!`;
        }
        return `📢 **सूचना / Notifications Status:**\n\n• **Hindi:** वर्तमान में एडमिन द्वारा कोई नया नोटिस या मैसेज जारी नहीं किया गया है। विद्यालय में कोई अवकाश नहीं है और **स्कूल खुला है (School is OPEN)**!\n\n• **English:** Currently, no new message or notice has been posted by the admin. **The school is OPEN!**`;
      }

      // The latest notification added by admin is at index 0
      const latestNotice = notices[0];
      const isHoliday = latestNotice.category === 'holiday';
      const isExam = latestNotice.category === 'exam';
      const isEvent = latestNotice.category === 'event';
      const categoryBadge = isHoliday
        ? '🚨 अवकाश / छुट्टी (Holiday Notice)'
        : isExam
        ? '📝 परीक्षा सूचना (Exam Notice)'
        : isEvent
        ? '🏆 खेलकूद व शैक्षिक टूर (Event & Sports)'
        : '📢 सामान्य सूचना (General Notice)';

      if (lang === 'Deutsch') {
        return `📢 **Neueste Benachrichtigung der Schulleitung (Latest Notice by Admin):**\n\n` +
          `📌 **Titel:** ${latestNotice.title}\n` +
          `🏷️ **Kategorie:** ${latestNotice.category.toUpperCase()}\n` +
          `📅 **Datum:** ${latestNotice.date}\n` +
          `📝 **Details:**\n${latestNotice.content}\n\n` +
          (isHoliday ? `⚠️ **Status:** Die Schule ist an diesem Tag geschlossen (Holiday declared).` : `🏫 **Status:** Die Schule ist regulär geöffnet (School is OPEN).`);
      }

      return `📢 **एडमिन द्वारा जारी नवीनतम नोटिफिकेशन (Latest Notification Added by Admin):**\n\n` +
        `📌 **शीर्षक (Title):** ${latestNotice.title}\n` +
        `🏷️ **प्रकार (Category):** ${categoryBadge}\n` +
        `📅 **लागू दिनांक (Effective Date):** ${latestNotice.date}\n` +
        `📝 **मुख्य विवरण (Details):**\n${latestNotice.content}\n\n` +
        (isHoliday
          ? `⚠️ **School Status:** इस आधिकारिक नोटिस के अनुसार स्कूल में **अवकाश (Holiday / Leave)** रहेगा।\n\n`
          : `🏫 **School Status:** स्कूल खुला है (School is OPEN)। सभी कक्षाएं नियमित समय अनुसार संचालित होंगी।\n\n`) +
        (notices.length > 1
          ? `*(कुल ${notices.length} सक्रिय नोटिस उपलब्ध हैं। सभी नोटिस देखने के लिए Circulars & Notifications बोर्ड देखें।)*`
          : `*(यह वर्तमान में एडमिन द्वारा प्रकाशित सबसे नया आधिकारिक नोटिस है।)*`);
    }

    // 2. Holiday / Open Question
    const isHolidayQuestion =
      lower.includes('holiday') ||
      lower.includes('chutti') ||
      lower.includes('chhutti') ||
      lower.includes('leave') ||
      lower.includes('open') ||
      lower.includes('khula') ||
      lower.includes('khulega') ||
      lower.includes('band') ||
      lower.includes('off') ||
      lower.includes('feiertag') ||
      lower.includes('ferien') ||
      lower.includes('geöffnet') ||
      lower.includes('geschlossen') ||
      lower.includes('kal');

    if (isHolidayQuestion) {
      if (activeHolidayNotice) {
        if (lang === 'Deutsch') {
          return `📌 **Schulfrei / Feiertag (Holiday Declared):**\n\nGemäß der offiziellen Mitteilung der NJS Public School ist die Schule geschlossen.\n**Titel:** ${activeHolidayNotice.title}\n**Details:** ${activeHolidayNotice.content}`;
        }
        return `📌 **Holiday Declared / छुट्टी घोषित:**\n\n• **Hindi / Hinglish:** हाँ, NJS Public School के आधिकारिक नोटिस के अनुसार स्कूल में **छुट्टी (Holiday / Leave)** रहेगी।\n  **शीर्षक:** ${activeHolidayNotice.title}\n  **विवरण:** ${activeHolidayNotice.content}\n\n• **English:** Yes! According to the active school notice, NJS Public School is **CLOSED / on Holiday** (${activeHolidayNotice.date}).\n  **Notice:** ${activeHolidayNotice.content}`;
      } else {
        if (lang === 'Deutsch') {
          return `🏫 **Die Schule ist geöffnet (School is OPEN):**\n\nEs liegt kein offizieller Feiertagsbescheid vor. Alle Klassen und der reguläre Stundenplan finden wie gewohnt statt.`;
        }
        return `🏫 **School is OPEN / स्कूल खुला है:**\n\n• **Hindi / Hinglish:** **स्कूल खुला है (School is OPEN)!** वर्तमान में विद्यालय प्रबंधन द्वारा किसी भी प्रकार के अवकाश (Holiday) की घोषणा नहीं की गई है। सभी कक्षाएं नियमित समय सारिणी अनुसार संचालित होंगी।\n\n• **English:** **The school is OPEN!** No holiday notice is currently in effect. All classes and academic schedules will function normally.`;
      }
    }

    // 3. Admissions & Enrollment Question (Ask AI core capability)
    const isAdmissionsQuestion =
      lower.includes('admission') ||
      lower.includes('enroll') ||
      lower.includes('enrolment') ||
      lower.includes('admissions') ||
      lower.includes('apply') ||
      lower.includes('entry') ||
      lower.includes('fee') ||
      lower.includes('fees') ||
      lower.includes('scholarship') ||
      lower.includes('daakhila') ||
      lower.includes('dakhila') ||
      lower.includes('प्रवेश') ||
      lower.includes('दाखिला') ||
      lower.includes('anmeldung');

    if (isAdmissionsQuestion) {
      if (lang === 'Deutsch') {
        return `🎓 **Aufnahme & Anmeldung an der NJS Public School (Admissions):**\n\n• **Klassenstufen:** Aufnahme für Pre-K bis Klasse 12 geöffnet.\n• **Voraussetzungen:** Geburtsurkunde, bisherige Zeugnisse, Übertragungsbescheinigung (TC) und 4 Passfotos.\n• **Stipendien:** Leistungsstipendien für Sportler (insb. 400m-Laufbahn) und akademische Spitzenleistungen.\n• **Ticket einreichen:** Klicken Sie auf **"Submit Parent Inquiry Ticket"**, um direkt eine Anfrage an unser Schulbüro zu senden!`;
      }
      return `🎓 **NJS Public School Admissions & Enrollment (24/7 Virtual Desk):**\n\n• **Available Grades:** Admissions are open from **Pre-Kindergarten to Grade 12** on a rolling basis.\n• **Eligibility:** Pre-K (Age 3+), Grade 1 (Age 6+).\n• **Documentation Required:**\n  1. Original Birth Certificate\n  2. Transfer Certificate (TC) & Previous Year Report Cards\n  3. 4 Passport-sized photographs of student & parents\n  4. Proof of Residence & ID Proof\n• **Scholarships:** Merit scholarships up to 50% tuition reduction for athletic achievers (400m track) and academic rankers.\n• **Next Step:** Click the **"📝 Submit Parent Inquiry"** button to register a priority inquiry ticket or request a campus tour!`;
    }

    // 4. Timings & Daily Routine
    const isTimingsQuestion =
      lower.includes('timing') ||
      lower.includes('time') ||
      lower.includes('hours') ||
      lower.includes('schedule') ||
      lower.includes('samay') ||
      lower.includes('समय') ||
      lower.includes('öffnungszeiten');

    if (isTimingsQuestion) {
      return `⏰ **NJS Public School Campus Timings & Daily Schedule:**\n\n• **Summer Timings:** 7:45 AM – 1:45 PM\n• **Winter Timings:** 8:30 AM – 2:30 PM\n• **Working Days:** Monday to Saturday (2nd & 4th Saturdays are co-curricular development days)\n• **Office & Admissions Desk:** 8:00 AM – 4:00 PM (Monday to Saturday)`;
    }

    // 5. Transportation & Bus Routes
    const isTransportQuestion =
      lower.includes('bus') ||
      lower.includes('transport') ||
      lower.includes('pickup') ||
      lower.includes('van') ||
      lower.includes('route') ||
      lower.includes('vahan');

    if (isTransportQuestion) {
      return `🚌 **Safe Transportation & GPS Bus Fleet:**\n\n• **Coverage:** Dedicated bus routes covering all major city sectors and surrounding regions.\n• **Safety Standards:** All buses equipped with GPS live tracking, speed governors (<40 km/h), emergency first-aid, and trained female attendants onboard.\n• **Inquiries:** Submit an inquiry ticket with your pickup location for exact route timing.`;
    }

    // 6. Cafeteria & Nutrition
    const isLunchQuestion =
      lower.includes('lunch') ||
      lower.includes('food') ||
      lower.includes('cafeteria') ||
      lower.includes('canteen') ||
      lower.includes('khana') ||
      lower.includes('diet') ||
      lower.includes('mittagessen');

    if (isLunchQuestion) {
      return `🍽️ **NJS School Nutrition & Cafeteria:**\n\n• 100% fresh, hygienic vegetarian meals cooked daily in our modern automated kitchen.\n• Dietitian-planned menu with balanced proteins, grains, seasonal fruits, and RO drinking water.\n• Strict food safety and allergy-safe preparation protocols.`;
    }

    // 7. Password question
    if (lower.includes('password') || lower.includes('passcode') || lower.includes('admin key')) {
      return `🔒 **Admin Notification Security:**\n\nएडमिन नोटिफिकेशन पासवर्ड निजी और सुरक्षित (Private & Confidential) है। केवल विद्यालय प्रबंधन द्वारा ही आधिकारिक नोटिफिकेशन प्रकाशित किए जा सकते हैं।`;
    }

    // 8. Hastinapur trip
    if (lower.includes('hastinapur') || lower.includes('tour') || lower.includes('trip') || lower.includes('excursion') || lower.includes('ausflug')) {
      return `🚌 **हस्तिनापुर शैक्षिक भ्रमण (Hastinapur Educational Excursion):**\n\nNJS Public School द्वारा विद्यार्थियों के लिए ऐतिहासिक हस्तिनापुर (कुरु साम्राज्य के अवशेष व प्रसिद्ध जैन दिगंबर/श्वेतांबर तीर्थ) का शैक्षिक भ्रमण आयोजित किया जा रहा है।\n• 24/7 समर्पित शिक्षकों का मार्गदर्शन\n• सुरक्षित प्रमाणित लक्जरी बसें\n• पौष्टिक बुफे भोजन व प्राथमिक चिकित्सा व्यवस्था।`;
    }

    // 9. Sports / 400m track
    if (lower.includes('track') || lower.includes('sports') || lower.includes('race') || lower.includes('khel') || lower.includes('athletic')) {
      return `🏃 **400m Olympic-Grade Athletic Track & Sports:**\n\nNJS Public School परिसर में अंतर्राष्ट्रीय मानकों का 400-मीटर ऑल-वेदर एथलेटिक्स ट्रैक, बास्केटबॉल कोर्ट, व फुटबॉल टर्फ मैदान उपलब्ध है जहाँ छात्रों को विशेष खेल प्रशिक्षण दिया जाता है।`;
    }

    // 10. YouTube Channel
    if (lower.includes('youtube') || lower.includes('channel') || lower.includes('video') || lower.includes('anant')) {
      return `▶️ **NJS Official YouTube Channel: @anantgahlaut**\n\nस्कूल के सभी वार्षिक उत्सव (Annual Functions), 400m स्पोर्ट्स रेस, सांस्कृतिक कार्यक्रम और छात्र प्रस्तुतियां आधिकारिक यूट्यूब चैनल पर उपलब्ध हैं:\n👉 https://www.youtube.com/@anantgahlaut`;
    }

    // 11. General greeting / Default
    if (lang === 'Deutsch') {
      return `Willkommen bei **Ask AI** der NJS Public School! Wir beantworten Ihre Fragen 24/7.\n\n• **Neueste Mitteilung:** Fragen Sie *"Gibt es neue Mitteilungen?"*\n• **Schulbetrieb / Feiertag:** Fragen Sie *"Ist die Schule geöffnet?"*\n• **Anmeldung:** Fragen Sie *"Admissions"* oder reichen Sie ein Ticket ein.\n• **YouTube:** @anantgahlaut`;
    }

    return `नमस्ते! मैं NJS Public School का 24/7 **Ask AI** वर्चुअल सहायक हूँ।\n\n• **नया नोटिस / मैसेज:** पूछें *"क्या कोई नया नोटिस आया है?"* या *"New message?"* (एडमिन द्वारा जोड़ा गया नवीनतम नोटिफिकेशन प्राप्त होगा)\n• **छुट्टी जांचें:** पूछें *"Kal holiday hai kya?"* (यदि छुट्टी का नोटिस है तो छुट्टी बताएगा, अन्यथा कहेगा "School is OPEN!")\n• **प्रवेश व दाखिला:** पूछें *"Admissions process"* या 'Submit Inquiry Ticket' से दाखिला टिकट बनाएं।\n• **यूट्यूब चैनल:** @anantgahlaut`;
  };

  // Handle Embedded Quick Query
  const handleRunQuickQuery = async (customText?: string) => {
    const textToRun = (customText ?? quickQuery).trim();
    if (!textToRun) return;

    setIsQuickThinking(true);
    setQuickAnswer(null);

    // If it's the deterministic holiday or notice question, answer directly
    const lower = textToRun.toLowerCase();
    const isDeterministic =
      lower.includes('holiday') ||
      lower.includes('chutti') ||
      lower.includes('chhutti') ||
      lower.includes('open') ||
      lower.includes('khula') ||
      lower.includes('notice') ||
      lower.includes('मैसेज') ||
      lower.includes('message') ||
      lower.includes('नोटिस') ||
      lower.includes('password');

    if (isDeterministic) {
      setTimeout(() => {
        const answer = getAiAnswer(textToRun, selectedLanguage);
        setQuickAnswer(answer);
        setIsQuickThinking(false);
      }, 300);
      return;
    }

    // Try server API first
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3500);
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: textToRun,
          language: selectedLanguage,
          activeNotices: notices,
        }),
        signal: controller.signal,
      });
      clearTimeout(timeoutId);

      if (res.ok) {
        const data = await res.json();
        if (data && data.reply && !data.useFallback) {
          setQuickAnswer(data.reply);
          setIsQuickThinking(false);
          return;
        }
      }
    } catch {
      // Fallback
    }

    const answer = getAiAnswer(textToRun, selectedLanguage);
    setQuickAnswer(answer);
    setIsQuickThinking(false);
  };

  // Handle Chat message submit
  const handleSendChatMessage = async (textToSend?: string) => {
    const text = (textToSend ?? chatInput).trim();
    if (!text) return;

    const userMsg: ChatMessage = {
      id: 'usr-' + Date.now(),
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setChatMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setChatInput('');
    setIsAiThinking(true);

    const lower = text.toLowerCase();
    const isDeterministic =
      lower.includes('holiday') ||
      lower.includes('chutti') ||
      lower.includes('chhutti') ||
      lower.includes('open') ||
      lower.includes('khula') ||
      lower.includes('notice') ||
      lower.includes('मैसेज') ||
      lower.includes('message') ||
      lower.includes('नोटिस') ||
      lower.includes('password');

    let replyText = '';

    if (!isDeterministic) {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 3500);
        const res = await fetch('/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: text,
            language: selectedLanguage,
            activeNotices: notices,
          }),
          signal: controller.signal,
        });
        clearTimeout(timeoutId);

        if (res.ok) {
          const data = await res.json();
          if (data && data.reply && !data.useFallback) {
            replyText = data.reply;
          }
        }
      } catch {
        // Fallback
      }
    }

    if (!replyText) {
      replyText = getAiAnswer(text, selectedLanguage);
    }

    setIsAiThinking(false);
    const botMsg: ChatMessage = {
      id: 'bot-' + Date.now(),
      sender: 'bot',
      text: replyText,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setChatMessages((prev) => [...prev, botMsg]);
  };

  // Admin Password validator (supporting official admin passwords including gahlaut, @nant, njs@2026, admin123, njsadmin, seemaanant)
  const ADMIN_PASSWORDS = ['gahlaut', '@nant', 'njs@2026', 'admin123', 'njsadmin', 'seemaanant'];
  const isValidAdminPassword = (pwd: string) => {
    const clean = pwd.trim().toLowerCase();
    return ADMIN_PASSWORDS.includes(clean) || pwd.trim() === '@nant';
  };

  // Handle Save Notice / Notification with Admin Password Verification "gahlaut"
  const handlePublishNotice = (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordError('');

    const trimmedTitle = modalTitle.trim();
    const trimmedContent = modalContent.trim();

    if (!trimmedTitle || !trimmedContent) {
      setPasswordError('कृपया नोटिफिकेशन का शीर्षक और विवरण दोनों भरें। (Title & details are required)');
      return;
    }

    // ADMIN PASSWORD CHECK: Must match private admin password
    if (!isValidAdminPassword(modalPassword)) {
      setPasswordError('❌ गलत पासवर्ड! कृपया सही एडमिन पासवर्ड दर्ज करें। (Incorrect password! Please enter the private admin password)');
      return;
    }

    // Success! Create new notice (with optional image)
    const newNotice: SchoolNotice = {
      id: 'notice-' + Date.now(),
      title: trimmedTitle,
      content: trimmedContent,
      category: modalCategory,
      date: modalDate.trim() || 'Today',
      createdAt: Date.now(),
      imageUrl: modalNoticeImageUrl.trim() || undefined,
    };

    setNotices((prev) => [newNotice, ...prev]);

    // Save notice to persistent server database
    fetch('/api/notices', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ notice: newNotice }),
    })
      .then((r) => r.json())
      .then((res) => {
        if (res.lastUpdated) lastServerSyncRef.current = res.lastUpdated;
      })
      .catch((err) => console.error('Failed to save notice to server:', err));

    // Reset fields
    setModalTitle('');
    setModalContent('');
    setModalNoticeImageUrl('');
    setModalPassword('');
    setPasswordError('');
    setIsModalOpen(false);

    // Show toast
    setSuccessToast(`नोटिफिकेशन सफलतापूर्वक प्रकाशित हुआ (डेटा सर्वर में सुरक्षित): "${trimmedTitle}"`);
    setTimeout(() => setSuccessToast(''), 6000);

    // Also inject notification message in chat
    setChatMessages((prev) => [
      ...prev,
      {
        id: 'sys-' + Date.now(),
        sender: 'bot',
        text: `✅ **नया नोटिफिकेशन / नोटिस सफलतापूर्वक जारी हुआ (एडमिन पासवर्ड सत्यापित):**\n**${trimmedTitle}** (${newNotice.date})\n*अब AI सहायक इस नोटिफिकेशन के आधार पर उत्तर देगा। ${modalCategory === 'holiday' ? '⚠️ छुट्टी की पुष्टि सक्रिय हो गई है।' : ''}*`,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  };

  // Handle Delete Notice (with password confirmation)
  const handleDeleteNotice = (id: string, title: string) => {
    const inputPwd = window.prompt(`नोटिफिकेशन "${title}" हटाने के लिए एडमिन पासवर्ड दर्ज करें:\n(Enter admin password to delete):`);
    if (inputPwd === null) return;
    if (!isValidAdminPassword(inputPwd)) {
      window.alert('❌ गलत पासवर्ड! केवल मान्य एडमिन पासवर्ड के साथ ही नोटिफिकेशन हटाया जा सकता है।');
      return;
    }

    setNotices((prev) => prev.filter((n) => n.id !== id));

    // Delete notice from server database
    fetch(`/api/notices/${id}`, {
      method: 'DELETE',
    })
      .then((r) => r.json())
      .then((res) => {
        if (res.lastUpdated) lastServerSyncRef.current = res.lastUpdated;
      })
      .catch((err) => console.error('Failed to delete notice on server:', err));

    setSuccessToast(`नोटिफिकेशन हटाया गया: "${title}"`);
    setTimeout(() => setSuccessToast(''), 4000);
  };

  // Handle Clear All Notices (with password confirmation)
  const handleClearAllNotices = () => {
    const inputPwd = window.prompt('सभी स्कूल नोटिफिकेशन व सर्कुलर हटाने के लिए एडमिन पासवर्ड दर्ज करें:\n(Enter admin password to clear all notices):');
    if (inputPwd === null) return;
    if (!isValidAdminPassword(inputPwd)) {
      window.alert('❌ गलत पासवर्ड! केवल मान्य एडमिन पासवर्ड के साथ ही नोटिफिकेशन हटाए जा सकते हैं।');
      return;
    }

    setNotices([]);
    localStorage.removeItem('njs_school_notices_v4');

    // Clear notices on server database
    fetch('/api/notices/clear', {
      method: 'POST',
    })
      .then((r) => r.json())
      .then((res) => {
        if (res.lastUpdated) lastServerSyncRef.current = res.lastUpdated;
      })
      .catch((err) => console.error('Failed to clear notices on server:', err));

    setSuccessToast('सभी स्कूल नोटिफिकेशन व सर्कुलर सफलतापूर्वक हटा दिए गए हैं (स्कूल खुला है)।');
    setTimeout(() => setSuccessToast(''), 5000);
  };

  // =========================================================================
  // IMAGE TESTING ENGINE (Add, upload, test presets, custom targets & lightbox)
  // =========================================================================

  // 1. File Upload Reader for local test images
  const handleImageFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setSuccessToast('⚠️ कृपया एक मान्य छवि फ़ाइल (JPG, PNG, WebP) चुनें।');
      setTimeout(() => setSuccessToast(''), 4000);
      return;
    }

    const sizeKb = Math.round(file.size / 1024);
    const sizeStr = sizeKb > 1024 ? `${(sizeKb / 1024).toFixed(1)} MB` : `${sizeKb} KB`;
    setTestImageFileSize(sizeStr);

    const reader = new FileReader();
    reader.onload = (loadEvt) => {
      const dataUrl = loadEvt.target?.result as string;
      setTestImageUrl(dataUrl);

      const cleanName = file.name.replace(/\.[^/.]+$/, '').replace(/[-_]/g, ' ');
      if (!testImageTitle) {
        setTestImageTitle(cleanName.charAt(0).toUpperCase() + cleanName.slice(1));
      }
      if (!testImageSubtitle) {
        setTestImageSubtitle(`Test image uploaded (${sizeStr}) • ${new Date().toLocaleDateString()}`);
      }

      // Read natural dimensions
      const img = new window.Image();
      img.onload = () => {
        setTestImageDimensions({ width: img.naturalWidth, height: img.naturalHeight });
      };
      img.src = dataUrl;
    };
    reader.readAsDataURL(file);
  };

  // 2. Select Sample Test Preset
  const handleSelectSampleImage = (sample: (typeof SAMPLE_TEST_IMAGES)[0]) => {
    setTestImageUrl(sample.url);
    setTestImageTitle(sample.title);
    setTestImageSubtitle(sample.subtitle);
    setTestImageAspect(sample.aspect);
    setTestImageFileSize('Online High-Res CDN');
    setTestImageDimensions({ width: 1200, height: 800 });
  };

  // 3. Confirm & Add Test Image to Site (with Admin Password Verification)
  const handleAddTestImage = () => {
    const url = testImageUrl.trim();
    if (!url) {
      setSuccessToast('⚠️ कृपया पहले कोई छवि अपलोड करें या URL दर्ज करें।');
      setTimeout(() => setSuccessToast(''), 3000);
      return;
    }

    // PASSWORD CHECK: User must enter valid admin password to upload / apply image
    if (!isValidAdminPassword(uploadImagePassword)) {
      setUploadImagePasswordError('❌ गलत पासवर्ड! छवि अपलोड करने व लागू करने के लिए कृपया मान्य एडमिन पासवर्ड दर्ज करें। (Invalid password! Enter admin password to upload image)');
      return;
    }
    setUploadImagePasswordError('');

    const title = testImageTitle.trim() || 'Custom Test Image';
    const subtitle = testImageSubtitle.trim() || `Added for UI testing • ${new Date().toLocaleDateString()}`;

    // =========================================================================
    // 🧪 MAKE ADDED IMAGE NOTICE BOX TEST IMAGE (सूचना पट्ट परीक्षण छवि)
    // Automatically sets Notice Box Test Image locally & permanently on server!
    // =========================================================================
    updateNoticeBoxTestImageStateAndServer(url, title);

    // Always preserve in gallery list for browsing and one-click reactivation
    const newPhoto: GalleryPhoto = {
      id: 'test-photo-' + Date.now(),
      url,
      title,
      subtitle,
      category: 'test',
      aspect: testImageAspect,
      isTest: true,
      timestamp: Date.now(),
      fileSize: testImageFileSize || undefined,
      dimensions: testImageDimensions ? `${testImageDimensions.width}x${testImageDimensions.height}` : undefined,
      filter: testImageFilter,
    };
    setGalleryPhotos((prev) => [newPhoto, ...prev.filter((p) => p.url !== url)]);

    // Save to server gallery database
    fetch('/api/gallery', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ photo: newPhoto }),
    })
      .then((r) => r.json())
      .then((res) => {
        if (res.lastUpdated) lastServerSyncRef.current = res.lastUpdated;
      })
      .catch(console.error);

    // Optional additional targets
    if (testImageTarget === 'hero' || testImageTarget === 'all') {
      setCustomHeroImage(url);
    }
    if (testImageTarget === 'logo' || testImageTarget === 'all') {
      setCustomLogoImage(url);
    }

    setSuccessToast(`✅ छवि सफलतापूर्वक Notice Box Test Image बनाई गई व सर्वर में सुरक्षित हुई: "${title}"`);
    setTimeout(() => setSuccessToast(''), 5000);
    setUploadImagePassword('');
    setIsTestImageModalOpen(false);

    // Smooth scroll down directly to Notice Box to see the newly applied test image
    setTimeout(() => {
      const el = document.getElementById('notices');
      if (el) el.scrollIntoView({ behavior: 'smooth' });
    }, 200);
  };

  // 4. Remove a Photo from Gallery
  const handleRemovePhoto = (id: string, title: string) => {
    setGalleryPhotos((prev) => prev.filter((p) => p.id !== id));
    if (lightboxPhoto?.id === id) setLightboxPhoto(null);

    // Delete from server gallery
    fetch(`/api/gallery/${id}`, {
      method: 'DELETE',
    })
      .then((r) => r.json())
      .then((res) => {
        if (res.lastUpdated) lastServerSyncRef.current = res.lastUpdated;
      })
      .catch(console.error);

    setSuccessToast(`छवि हटाई गई: "${title}"`);
    setTimeout(() => setSuccessToast(''), 3000);
  };

  // 5. Reset Gallery to Authentic School Defaults
  const handleResetGallery = () => {
    setGalleryPhotos(DEFAULT_GALLERY_PHOTOS);
    setCustomHeroImage(null);
    setCustomLogoImage(null);
    localStorage.removeItem('njs_gallery_photos_v2');
    setSuccessToast('गैलरी मूल स्थिति में रीसेट कर दी गई (Default school photos restored)');
    setTimeout(() => setSuccessToast(''), 4000);
  };

  const filteredNotices = notices.filter((n) => (activeFilter === 'all' ? true : n.category === activeFilter));

  return (
    <div className="min-h-screen bg-slate-900/5 text-slate-800 flex flex-col font-['Poppins',sans-serif]">
      {/* Success Toast */}
      {successToast && (
        <div className="fixed top-5 right-5 z-[9999] bg-emerald-600 text-white px-5 py-3.5 rounded-2xl shadow-2xl flex items-center gap-3 border border-emerald-400 animate-bounce text-sm font-medium">
          <CheckCircle2 className="w-5 h-5 flex-shrink-0" />
          <span>{successToast}</span>
          <button onClick={() => setSuccessToast('')} className="ml-2 hover:opacity-80">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* TOP ANNOUNCEMENT BAR */}
      <div className="bg-[#090d16] text-slate-300 text-xs px-4 py-2 border-b border-slate-800/80">
        <div className="max-w-7xl mx-auto flex flex-wrap justify-between items-center gap-2">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="inline-flex items-center gap-1 font-semibold text-emerald-400">
              <School className="w-3.5 h-3.5" /> NJS Public School
            </span>
            <span className="text-slate-600">•</span>
            <span>Creator of Knowledge</span>
            <span className="text-slate-600">•</span>
            <a href="mailto:seemaanantom@gmail.com" className="text-sky-400 hover:underline">
              seemaanantom@gmail.com
            </a>
          </div>

          <div className="flex items-center gap-3">
            {/* Cloud Database Sync Status */}
            <button
              onClick={() => fetchServerData()}
              className="inline-flex items-center gap-1.5 text-slate-300 text-[11px] bg-slate-800/90 hover:bg-slate-700/90 px-2.5 py-0.5 rounded-full border border-slate-700 cursor-pointer transition shadow-xs"
              title={`Persistent Multi-User Cloud Storage: Any detail added is saved and shared for all users. Last synced: ${lastSyncTime || 'Just now'}. Click to sync.`}
            >
              <span className={`w-2 h-2 rounded-full ${isServerConnected ? 'bg-emerald-400' : 'bg-amber-400 animate-pulse'}`} />
              <span className="hidden sm:inline font-semibold">{isServerConnected ? 'Cloud Stored' : 'Connecting...'}</span>
              <RefreshCw className={`w-3 h-3 text-slate-400 ${isSyncing ? 'animate-spin text-emerald-400' : ''}`} />
            </button>

            <button
              onClick={() => setIsDownloadModalOpen(true)}
              className="inline-flex items-center gap-1.5 bg-sky-500/20 text-sky-300 hover:bg-sky-500/30 px-3 py-1 rounded-full transition border border-sky-500/40 font-medium"
              title="Download School Portal File, Offline App & Prospectus"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download File (डाउनलोड)</span>
            </button>

            <button
              onClick={() => setIsAiDrawerOpen(true)}
              className="inline-flex items-center gap-1.5 bg-emerald-500/20 text-emerald-300 px-3 py-1 rounded-full hover:bg-emerald-500/30 transition border border-emerald-500/40 font-medium"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>AI सहायता (Holo Mode)</span>
            </button>

            <a
              href="https://www.youtube.com/@anantgahlaut"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-1.5 bg-red-600/20 text-red-400 hover:bg-red-600 hover:text-white px-3 py-1 rounded-full transition border border-red-500/30 font-medium"
            >
              <Youtube className="w-3.5 h-3.5" />
              <span>@anantgahlaut</span>
            </a>
          </div>
        </div>
      </div>

      {/* MAIN NAVIGATION HEADER */}
      <header className="bg-white/95 backdrop-blur-md sticky top-0 z-40 border-b border-slate-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex justify-between items-center">
          {/* Logo Area */}
          <a href="#" className="flex items-center gap-3 group">
            <img
              src="https://seemaanantom-eng.github.io/NJSpublicSchool/apple.jpg"
              alt="NJS Public School Logo"
              className="w-11 h-11 rounded-xl object-cover shadow-md group-hover:scale-105 transition"
            />
            <div>
              <div className="font-['Playfair_Display',serif] text-xl font-extrabold text-slate-900 tracking-tight leading-none">
                NJS PUBLIC SCHOOL
              </div>
              <div className="text-[11px] font-bold text-emerald-600 tracking-wider uppercase mt-1">
                Creator of Knowledge
              </div>
            </div>
          </a>

          {/* Nav Links */}
          <nav className="hidden md:flex items-center gap-5 text-sm font-semibold text-slate-700">
            <a href="#about" className="hover:text-emerald-600 transition">About</a>
            <a href="#notices" className="hover:text-emerald-600 transition flex items-center gap-1">
              <span>Notifications & Notices</span>
              {notices.length > 0 && (
                <span className="bg-emerald-100 text-emerald-700 text-[10px] px-1.5 py-0.5 rounded-full font-bold">
                  {notices.length}
                </span>
              )}
            </a>
            <a href="#sports" className="hover:text-emerald-600 transition">Sports Track</a>
            <a href="#hastinapur" className="hover:text-emerald-600 transition">Excursion</a>
            <button
              onClick={() => setIsDownloadModalOpen(true)}
              className="hover:text-sky-600 transition flex items-center gap-1 text-slate-700"
            >
              <Download className="w-4 h-4 text-sky-600" />
              <span>Download</span>
            </button>
            <a
              href="https://www.youtube.com/@anantgahlaut"
              target="_blank"
              rel="noopener noreferrer"
              className="text-red-600 hover:text-red-700 transition flex items-center gap-1"
            >
              <Youtube className="w-4 h-4" /> YouTube
            </a>
          </nav>

          {/* Action Buttons */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            {/* ADD TEST IMAGE BUTTON */}
            <button
              onClick={() => setIsTestImageModalOpen(true)}
              className="bg-amber-500 hover:bg-amber-600 text-slate-950 text-xs sm:text-sm font-bold px-2 sm:px-3 py-1.5 sm:py-2 rounded-xl shadow-sm hover:shadow transition flex items-center gap-1.5"
              title="Add Any Image for Test (छवि जोड़ें / परीक्षण)"
            >
              <ImagePlus className="w-4 h-4 text-slate-950" />
              <span className="hidden md:inline">Test Image</span>
              <span className="md:hidden text-xs">Test</span>
            </button>

            {/* DOWNLOAD FILE BUTTON */}
            <button
              onClick={() => setIsDownloadModalOpen(true)}
              className="bg-sky-600 hover:bg-sky-700 text-white text-xs sm:text-sm font-semibold px-2.5 sm:px-3.5 py-1.5 sm:py-2 rounded-xl shadow-sm hover:shadow transition flex items-center gap-1.5"
              title="Download Portal File / Offline HTML & Documents"
            >
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">Download File</span>
              <span className="sm:hidden text-xs">Download</span>
            </button>

            {/* ADD NOTIFICATION / NOTICE PROTECTED BUTTON */}
            <button
              onClick={() => {
                setPasswordError('');
                setIsModalOpen(true);
              }}
              className="bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-semibold px-2.5 sm:px-3.5 py-1.5 sm:py-2 rounded-xl shadow-sm hover:shadow transition flex items-center gap-1.5"
              title="Add Notification (Admin Only)"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">Add Notification</span>
              <span className="sm:hidden text-xs">Add</span>
            </button>

            {/* ASK AI ASSISTANT BUTTON */}
            <button
              onClick={() => setIsAiDrawerOpen(true)}
              className="bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white text-xs sm:text-sm font-semibold px-3 sm:px-4 py-1.5 sm:py-2 rounded-xl shadow-md hover:shadow-lg transition flex items-center gap-1.5 sm:gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span className="hidden xs:inline">Ask AI</span>
            </button>

            {/* MOBILE HAMBURGER TOGGLE */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="md:hidden p-2 rounded-xl text-slate-700 hover:bg-slate-100 transition active:scale-95"
              aria-label="Toggle mobile menu"
            >
              {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* MOBILE SLIDE-DOWN DRAWER MENU */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-white border-t border-slate-200 px-4 py-4 space-y-3 shadow-2xl animate-in slide-in-from-top-2 duration-150">
            {/* School Status pill in Mobile Menu */}
            <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 flex items-center justify-between text-xs">
              <span className="text-slate-600 font-medium">Status:</span>
              <span className="font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                School is OPEN (स्कूल खुला है)
              </span>
            </div>

            <div className="text-xs text-slate-500 font-medium px-1 flex items-center justify-between">
              <span className="flex items-center gap-1 text-slate-600">
                <Lock className="w-3.5 h-3.5 text-indigo-600" /> Admin Protected
              </span>
              <span className="text-emerald-600 font-semibold">AI Assistant Ready</span>
            </div>

            <nav className="flex flex-col space-y-1 text-sm font-semibold text-slate-700 pt-1">
              <a
                href="#about"
                onClick={() => setIsMobileMenuOpen(false)}
                className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-slate-100 transition"
              >
                <Home className="w-4 h-4 text-emerald-600" />
                <span>About NJS School</span>
              </a>

              <a
                href="#notices"
                onClick={() => setIsMobileMenuOpen(false)}
                className="flex items-center justify-between p-2.5 rounded-xl hover:bg-slate-100 transition"
              >
                <div className="flex items-center gap-3">
                  <Bell className="w-4 h-4 text-indigo-600" />
                  <span>Circulars & Notifications</span>
                </div>
                {notices.length > 0 && (
                  <span className="bg-emerald-100 text-emerald-700 text-xs px-2 py-0.5 rounded-full font-bold">
                    {notices.length}
                  </span>
                )}
              </a>

              <a
                href="#community-gallery"
                onClick={() => setIsMobileMenuOpen(false)}
                className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-slate-100 transition"
              >
                <Camera className="w-4 h-4 text-amber-500" />
                <span>Photo Gallery & Community</span>
              </a>

              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  setIsTestImageModalOpen(true);
                }}
                className="w-full text-left flex items-center gap-3 p-2.5 rounded-xl text-amber-900 bg-amber-50 hover:bg-amber-100 transition font-bold"
              >
                <ImagePlus className="w-4 h-4 text-amber-600" />
                <span>🧪 Test Any Image (छवि जोड़ें)</span>
              </button>

              <a
                href="#sports"
                onClick={() => setIsMobileMenuOpen(false)}
                className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-slate-100 transition"
              >
                <Trophy className="w-4 h-4 text-indigo-500" />
                <span>400m Olympic Sports Track</span>
              </a>

              <a
                href="#hastinapur"
                onClick={() => setIsMobileMenuOpen(false)}
                className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-slate-100 transition"
              >
                <Bus className="w-4 h-4 text-emerald-500" />
                <span>Hastinapur Educational Tour</span>
              </a>

              <a
                href="https://www.youtube.com/@anantgahlaut"
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setIsMobileMenuOpen(false)}
                className="flex items-center justify-between p-2.5 rounded-xl text-red-600 hover:bg-red-50 transition"
              >
                <div className="flex items-center gap-3">
                  <Youtube className="w-4 h-4" />
                  <span>YouTube @anantgahlaut</span>
                </div>
                <ExternalLink className="w-3.5 h-3.5" />
              </a>

              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  setIsDownloadModalOpen(true);
                }}
                className="w-full text-left flex items-center gap-3 p-2.5 rounded-xl text-sky-800 bg-sky-50 hover:bg-sky-100 transition font-bold"
              >
                <Download className="w-4 h-4 text-sky-600" />
                <span>Download Portal File & Prospectus</span>
              </button>

              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  setIsAiDrawerOpen(true);
                }}
                className="w-full text-left flex items-center gap-3 p-2.5 rounded-xl text-emerald-700 bg-emerald-50 hover:bg-emerald-100 transition font-bold"
              >
                <Sparkles className="w-4 h-4" />
                <span>Open School AI Assistant (पूछें)</span>
              </button>

              <button
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  setPasswordError('');
                  setIsModalOpen(true);
                }}
                className="w-full text-left flex items-center gap-3 p-2.5 rounded-xl text-indigo-700 bg-indigo-50 hover:bg-indigo-100 transition font-bold"
              >
                <KeyRound className="w-4 h-4" />
                <span>Add Notification (Admin Only)</span>
              </button>
            </nav>
          </div>
        )}
      </header>

      {/* HERO SECTION */}
      <section id="about" className="relative bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950 text-white py-16 sm:py-24 px-4 overflow-hidden">
        {/* Subtle background glow */}
        <div className="absolute top-0 right-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-10 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />

        {/* Custom Test Background Image (if active) */}
        {customHeroImage && (
          <div
            className="absolute inset-0 bg-cover bg-center opacity-30 pointer-events-none transition-all duration-500"
            style={{ backgroundImage: `url(${customHeroImage})` }}
          />
        )}

        <div className="max-w-4xl mx-auto text-center relative z-10">
          <div className="inline-flex items-center gap-2 bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs sm:text-sm font-semibold px-4 py-1.5 rounded-full mb-6 uppercase tracking-wider">
            <Sparkles className="w-4 h-4" />
            <span>Excellence in Education • AI Powered Campus</span>
          </div>

          <h1 className="font-['Playfair_Display',serif] text-4xl sm:text-6xl font-extrabold tracking-tight mb-5 leading-tight">
            NJS Public School
          </h1>

          <p className="text-slate-300 text-base sm:text-xl font-light max-w-2xl mx-auto mb-8 leading-relaxed">
            Nurturing young minds through holistic academics, 400m Olympic-standard athletics, historical excursions to Hastinapur, and real-time AI school assistance.
          </p>

          {/* Custom Hero Image Test Indicator (if set) */}
          {customHeroImage && (
            <div className="mb-4 inline-flex items-center gap-2 bg-amber-500/20 border border-amber-400/40 text-amber-300 px-4 py-1 rounded-full text-xs font-semibold backdrop-blur">
              <FlaskConical className="w-3.5 h-3.5 text-amber-400" />
              <span>Custom Hero Background Active for Testing</span>
              <button
                onClick={() => setCustomHeroImage(null)}
                className="underline ml-1 hover:text-white font-bold"
              >
                Clear
              </button>
            </div>
          )}

          {/* Quick status pill */}
          <div className="mb-8 block sm:inline-flex items-center gap-3 bg-slate-800/80 backdrop-blur border border-slate-700 px-5 py-2.5 rounded-2xl shadow-inner text-sm">
            <span className="flex h-3 w-3 relative mx-auto sm:mx-0 mb-1 sm:mb-0">
              <span className={`animate-ping absolute inline-flex h-full w-full rounded-full opacity-75 ${activeHolidayNotice ? 'bg-amber-400' : 'bg-emerald-400'}`} />
              <span className={`relative inline-flex rounded-full h-3 w-3 ${activeHolidayNotice ? 'bg-amber-500' : 'bg-emerald-500'}`} />
            </span>
            <span className="text-slate-200">
              Current School Status: <strong className={activeHolidayNotice ? 'text-amber-300' : 'text-emerald-400'}>
                {activeHolidayNotice ? 'Holiday / Leave Declared' : 'School is OPEN (स्कूल खुला है)'}
              </strong>
            </span>
          </div>

          {/* Action CTAs */}
          <div className="flex flex-wrap justify-center gap-3.5">
            <button
              onClick={() => setIsTestImageModalOpen(true)}
              className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-5 py-3 rounded-full transition shadow-lg shadow-amber-500/25 flex items-center gap-2 border border-amber-300"
              title="Add Any Image for Test (Upload file or enter URL)"
            >
              <ImagePlus className="w-5 h-5 text-slate-950" />
              <span>Test Any Image (छवि जोड़ें)</span>
            </button>

            <button
              onClick={() => setIsDownloadModalOpen(true)}
              className="bg-sky-600 hover:bg-sky-700 text-white font-semibold px-6 py-3 rounded-full transition shadow-lg shadow-sky-600/30 flex items-center gap-2 border border-sky-400/30"
            >
              <Download className="w-5 h-5" />
              <span>Download File (.html)</span>
            </button>

            <button
              onClick={() => setIsAiDrawerOpen(true)}
              className="bg-emerald-500 hover:bg-emerald-600 text-white font-semibold px-6 py-3 rounded-full transition shadow-lg shadow-emerald-500/20 flex items-center gap-2"
            >
              <Sparkles className="w-5 h-5" />
              <span>Open AI Assistant (पूछें)</span>
            </button>

            <button
              onClick={() => {
                setPasswordError('');
                setIsModalOpen(true);
              }}
              className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold px-6 py-3 rounded-full transition shadow-lg shadow-indigo-600/20 flex items-center gap-2 border border-indigo-400/30"
            >
              <KeyRound className="w-5 h-5" />
              <span>Add Notification (Admin Only)</span>
            </button>

            <a
              href="#notices"
              className="bg-white/10 hover:bg-white/15 text-white font-semibold px-6 py-3 rounded-full transition border border-white/20 flex items-center gap-2"
            >
              <Bell className="w-5 h-5" />
              <span>Active Notices ({notices.length})</span>
            </a>
          </div>
        </div>
      </section>

      {/* MAIN CONTENT AREA */}
      <main className="max-w-7xl mx-auto px-3.5 sm:px-6 pt-6 pb-28 sm:py-12 flex-1 w-full space-y-8 sm:space-y-12">
        {/* 1. EMBEDDED AI QUICK ASSISTANT BOX */}
        <section className="bg-gradient-to-br from-slate-900 via-emerald-950 to-slate-900 rounded-3xl p-6 sm:p-8 text-white border border-emerald-500/30 shadow-xl relative overflow-hidden">
          <div className="flex flex-wrap justify-between items-start gap-4 mb-6">
            <div>
              <div className="flex items-center gap-2 text-emerald-400 font-bold text-xs uppercase tracking-wider mb-1">
                <Sparkles className="w-4 h-4" /> Real-time Bilingual Assistant
              </div>
              <h2 className="font-['Playfair_Display',serif] text-2xl sm:text-3xl font-bold text-white">
                School AI Hub (हिंदी / Hinglish / English)
              </h2>
              <p className="text-slate-400 text-sm mt-1">
                छुट्टी, परीक्षा, या नोटिस की तुरंत पुष्टि करें। कोई छुट्टी न होने पर AI कहेगा: School is OPEN!
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="bg-emerald-500/20 text-emerald-300 text-xs px-3 py-1 rounded-full border border-emerald-500/40 font-medium">
                ⚡ Gemini 3.8 Flash Engine
              </span>
              <button
                onClick={() => {
                  setPasswordError('');
                  setIsModalOpen(true);
                }}
                className="bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold px-3 py-1 rounded-full transition flex items-center gap-1.5"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Notification Manager</span>
              </button>
            </div>
          </div>

          {/* Quick Input Bar */}
          <div className="flex flex-col sm:flex-row gap-2.5 mb-4">
            <div className="relative flex-1">
              <input
                type="text"
                value={quickQuery}
                onChange={(e) => setQuickQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleRunQuickQuery()}
                placeholder="उदा. 'Kal holiday hai kya?', 'Is school open tomorrow?', 'Notice details'..."
                className="w-full bg-slate-950/80 border border-slate-700 rounded-2xl px-5 py-3.5 text-sm text-white placeholder-slate-400 focus:outline-none focus:border-emerald-400 transition pr-10"
              />
              {quickQuery && (
                <button
                  onClick={() => {
                    setQuickQuery('');
                    setQuickAnswer(null);
                  }}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            <button
              onClick={() => handleRunQuickQuery()}
              disabled={isQuickThinking || !quickQuery.trim()}
              className="bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 text-white font-semibold px-6 py-3.5 rounded-2xl transition flex items-center justify-center gap-2 flex-shrink-0"
            >
              {isQuickThinking ? (
                <>
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  <span>Checking...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Ask AI (उत्तर पाएं)</span>
                </>
              )}
            </button>
          </div>

          {/* Preset Query Chips */}
          <div className="flex flex-wrap gap-2 text-xs">
            <button
              onClick={() => {
                setQuickQuery('Kal holiday hai kya?');
                handleRunQuickQuery('Kal holiday hai kya?');
              }}
              className="bg-white/10 hover:bg-emerald-500/20 hover:border-emerald-400/50 text-slate-200 px-3.5 py-1.5 rounded-xl border border-white/10 transition"
            >
              📅 "Kal holiday hai kya?"
            </button>
            <button
              onClick={() => {
                setQuickQuery('Is school open tomorrow?');
                handleRunQuickQuery('Is school open tomorrow?');
              }}
              className="bg-white/10 hover:bg-emerald-500/20 hover:border-emerald-400/50 text-slate-200 px-3.5 py-1.5 rounded-xl border border-white/10 transition"
            >
              🏫 "Is school open tomorrow?"
            </button>
            <button
              onClick={() => {
                setPasswordError('');
                setIsModalOpen(true);
              }}
              className="bg-indigo-500/20 hover:bg-indigo-500/30 text-indigo-300 px-3.5 py-1.5 rounded-xl border border-indigo-500/40 transition font-medium flex items-center gap-1"
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>➕ "Add Notification (Admin)"</span>
            </button>
            <button
              onClick={() => {
                setQuickQuery('क्या कोई नया नोटिस आया है?');
                handleRunQuickQuery('क्या कोई नया नोटिस आया है?');
              }}
              className="bg-white/10 hover:bg-emerald-500/20 hover:border-emerald-400/50 text-slate-200 px-3.5 py-1.5 rounded-xl border border-white/10 transition"
            >
              📢 "क्या कोई नया नोटिस आया है?"
            </button>
            <button
              onClick={() => {
                setQuickQuery('New message?');
                handleRunQuickQuery('New message?');
              }}
              className="bg-white/10 hover:bg-emerald-500/20 hover:border-emerald-400/50 text-slate-200 px-3.5 py-1.5 rounded-xl border border-white/10 transition"
            >
              💬 "New message?"
            </button>
            <button
              onClick={() => {
                setQuickQuery('Hastinapur excursion trip details');
                handleRunQuickQuery('Hastinapur excursion trip details');
              }}
              className="bg-white/10 hover:bg-emerald-500/20 hover:border-emerald-400/50 text-slate-200 px-3.5 py-1.5 rounded-xl border border-white/10 transition"
            >
              🚌 "Hastinapur trip details"
            </button>
          </div>

          {/* Quick AI Response Display */}
          {quickAnswer && (
            <div className="mt-5 p-5 bg-slate-950/90 rounded-2xl border border-emerald-500/40 text-slate-200 text-sm leading-relaxed animate-in fade-in slide-in-from-top-2 duration-200">
              <div className="flex items-center justify-between mb-3 pb-2 border-b border-slate-800">
                <span className="text-emerald-400 font-bold text-xs flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4" /> AI Verified Response
                </span>
                <span className="text-slate-500 text-xs">Based on active notices</span>
              </div>
              <div className="whitespace-pre-line">{quickAnswer}</div>
            </div>
          )}
        </section>

        {/* 2. YOUTUBE CHANNEL SPOTLIGHT BANNER */}
        <section className="bg-gradient-to-r from-red-950 via-slate-900 to-red-950 rounded-3xl p-6 sm:p-8 text-white border border-red-500/30 shadow-xl flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-red-600/20 border border-red-500/40 flex items-center justify-center text-red-500 flex-shrink-0">
              <Youtube className="w-8 h-8" />
            </div>
            <div>
              <div className="inline-flex items-center gap-1.5 text-red-400 text-xs font-bold uppercase tracking-wider mb-1">
                Official YouTube Broadcasts
              </div>
              <h3 className="font-['Playfair_Display',serif] text-2xl font-bold">
                Channel @anantgahlaut
              </h3>
              <p className="text-slate-300 text-sm mt-1">
                वार्षिक उत्सव, 400m स्पोर्ट्स रेस, सांस्कृतिक कार्यक्रम व छात्र व्याख्यान देखें।
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <a
              href="https://www.youtube.com/@anantgahlaut"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-red-600 hover:bg-red-700 text-white font-bold px-6 py-3 rounded-full transition shadow-lg shadow-red-600/30 flex items-center gap-2 text-sm"
            >
              <Youtube className="w-5 h-5" />
              <span>Subscribe @anantgahlaut</span>
              <ExternalLink className="w-4 h-4" />
            </a>
          </div>
        </section>

        {/* 3. ACTIVE NOTICES BOARD (WITH PASSWORD PROTECTED ADD FEATURE) */}
        <section id="notices" className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-md">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-100">
            <div>
              <div className="flex items-center gap-2 text-indigo-600 text-xs font-bold uppercase tracking-wider mb-1">
                <Bell className="w-4 h-4" /> Official Notice Board
              </div>
              <h2 className="font-['Playfair_Display',serif] text-2xl sm:text-3xl font-extrabold text-slate-900">
                School Circulars & Notifications
              </h2>
              <p className="text-slate-500 text-sm mt-1">
                Verified notices issued by NJS Public School Administration
              </p>
            </div>

            {/* Notice Action Buttons */}
            <div className="flex flex-wrap items-center gap-2.5">
              {/* PRIMARY PROMPT REQUIREMENT: Add Notification with admin password "gahlaut" */}
              <button
                onClick={() => {
                  setPasswordError('');
                  setIsModalOpen(true);
                }}
                className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold px-4 py-2.5 rounded-xl shadow-md hover:shadow-lg transition flex items-center gap-2 text-sm"
              >
                <Plus className="w-4 h-4" />
                <span>Add Notification by Admin</span>
              </button>

              <button
                onClick={handleDownloadNoticesText}
                className="bg-sky-50 hover:bg-sky-100 text-sky-800 border border-sky-200 font-semibold px-3 py-2.5 rounded-xl transition text-sm flex items-center gap-1.5"
                title="Download all active circulars as a text file"
              >
                <Download className="w-4 h-4 text-sky-600" />
                <span>Download Circulars (.txt)</span>
              </button>

              <button
                onClick={handleClearAllNotices}
                className="bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 font-semibold px-3 py-2.5 rounded-xl transition text-sm flex items-center gap-1.5"
                title="Clear all circulars and notifications (Admin Password Required)"
              >
                <Trash2 className="w-4 h-4" />
                <span>Clear All (सभी हटाएं)</span>
              </button>

              <button
                onClick={() => {
                  setIsAiDrawerOpen(true);
                  handleSendChatMessage('Kal holiday hai kya?');
                }}
                className="bg-slate-900 hover:bg-slate-800 text-white font-semibold px-4 py-2.5 rounded-xl transition text-sm flex items-center gap-2"
              >
                <School className="w-4 h-4 text-emerald-400" />
                <span>Holiday Status</span>
              </button>
            </div>
          </div>

          {/* Filter Pills & Status */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-5 pb-4">
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs text-slate-400 font-medium flex items-center gap-1 mr-1">
                <Filter className="w-3.5 h-3.5" /> Filter:
              </span>
              {(['all', 'holiday', 'exam', 'event', 'general'] as const).map((cat) => (
                <button
                  key={cat}
                  onClick={() => setActiveFilter(cat)}
                  className={`text-xs font-semibold px-3.5 py-1.5 rounded-full transition capitalize ${
                    activeFilter === cat
                      ? 'bg-slate-900 text-white shadow-sm'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {cat === 'all'
                    ? `All (${notices.length})`
                    : cat === 'holiday'
                    ? 'Holiday / छुट्टी'
                    : cat === 'exam'
                    ? 'Exams'
                    : cat === 'event'
                    ? 'Events & Sports'
                    : 'General'}
                </button>
              ))}
            </div>

            {/* Current admin protected badge */}
            <div className="text-xs font-semibold px-3 py-1.5 rounded-xl flex items-center gap-2 bg-slate-50 border border-slate-200 text-slate-600">
              <Lock className="w-3.5 h-3.5 text-indigo-600" />
              <span>Admin Protected</span>
            </div>
          </div>

          {/* Notices Grid / List */}
          <div className="space-y-3.5 mt-2">
            {filteredNotices.length === 0 ? (
              <div className="text-center py-12 bg-slate-50 rounded-2xl border border-dashed border-slate-200">
                <Bell className="w-10 h-10 text-slate-300 mx-auto mb-2" />
                <p className="text-slate-600 font-medium text-sm">No notices or notifications active at this time.</p>
                <p className="text-emerald-600 text-xs mt-1 font-semibold">School is OPEN! (स्कूल खुला है!)</p>
                <button
                  onClick={() => {
                    setPasswordError('');
                    setIsModalOpen(true);
                  }}
                  className="mt-4 bg-indigo-600 text-white text-xs font-bold px-4 py-2 rounded-xl hover:bg-indigo-700 transition inline-flex items-center gap-1.5 shadow"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add Notification (Admin Only)</span>
                </button>
              </div>
            ) : (
              filteredNotices.map((notice) => {
                const isHoliday = notice.category === 'holiday';
                const isExam = notice.category === 'exam';
                const isEvent = notice.category === 'event';

                return (
                  <div
                    key={notice.id}
                    className={`p-5 rounded-2xl border transition hover:shadow-sm ${
                      isHoliday
                        ? 'bg-red-50/50 border-red-200 border-l-4 border-l-red-500'
                        : isExam
                        ? 'bg-amber-50/50 border-amber-200 border-l-4 border-l-amber-500'
                        : isEvent
                        ? 'bg-emerald-50/50 border-emerald-200 border-l-4 border-l-emerald-500'
                        : 'bg-slate-50 border-slate-200 border-l-4 border-l-indigo-500'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                      <div>
                        <div className="flex flex-wrap items-center gap-2 mb-1.5">
                          <span
                            className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider ${
                              isHoliday
                                ? 'bg-red-100 text-red-800'
                                : isExam
                                ? 'bg-amber-100 text-amber-800'
                                : isEvent
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-indigo-100 text-indigo-800'
                            }`}
                          >
                            {isHoliday
                              ? 'Holiday / छुट्टी'
                              : isExam
                              ? 'Exam Notice'
                              : isEvent
                              ? 'Event & Sports'
                              : 'General Notice'}
                          </span>

                          <span className="text-slate-400 text-xs flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            <span>{notice.date}</span>
                          </span>
                        </div>

                        <h4 className="text-base sm:text-lg font-bold text-slate-900 leading-snug">
                          {notice.title}
                        </h4>
                      </div>

                      <div className="flex items-center gap-1 self-start flex-shrink-0">
                        {/* Download notice as file */}
                        <button
                          onClick={() => handleDownloadSingleNotice(notice)}
                          className="text-slate-400 hover:text-sky-600 p-1.5 rounded-lg hover:bg-sky-50 transition"
                          title="Download this notice as text file (.txt)"
                        >
                          <FileDown className="w-4 h-4" />
                        </button>

                        {/* Delete button (protected by password prompt) */}
                        <button
                          onClick={() => handleDeleteNotice(notice.id, notice.title)}
                          className="text-slate-400 hover:text-red-600 p-1.5 rounded-lg hover:bg-red-50 transition"
                          title="Delete Notice (Admin password required)"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>

                    <p className="text-slate-700 text-sm mt-2 leading-relaxed">
                      {notice.content}
                    </p>

                    {notice.imageUrl && (
                      <div className="mt-3 rounded-xl overflow-hidden border border-slate-200/80 max-h-72 bg-slate-900/5 group relative">
                        <img
                          src={notice.imageUrl}
                          alt={notice.title}
                          className="w-full h-full object-cover max-h-72 cursor-pointer transition hover:scale-[1.01]"
                          onClick={() =>
                            setLightboxPhoto({
                              id: notice.id,
                              url: notice.imageUrl!,
                              title: notice.title,
                              subtitle: `Notice attachment • ${notice.date}`,
                              category: 'test',
                            })
                          }
                        />
                        <div className="absolute bottom-2 right-2 bg-slate-900/80 text-white text-[10px] font-bold px-2 py-0.5 rounded-full backdrop-blur pointer-events-none flex items-center gap-1">
                          <ZoomIn className="w-3 h-3" /> Click to enlarge
                        </div>
                      </div>
                    )}
                  </div>
                );
              })
            )}

            {/* ========================================================================= */}
            {/* 🧪 TEST IMAGE AT BOTTOM OF NOTICE BOX (सूचना पट्ट परीक्षण छवि)            */}
            {/* ========================================================================= */}
            <div className="mt-5 pt-5 border-t-2 border-dashed border-indigo-200/80 bg-gradient-to-br from-indigo-50/60 via-amber-50/30 to-slate-50 p-4 sm:p-5 rounded-2xl border border-indigo-100 shadow-sm">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3.5">
                <div>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="inline-flex items-center gap-1.5 bg-indigo-600 text-white text-[11px] font-extrabold px-3 py-1 rounded-full uppercase tracking-wider shadow-sm">
                      <FlaskConical className="w-3.5 h-3.5 text-amber-300" />
                      <span>Notice Box Test Image</span>
                    </span>
                    <span className="bg-emerald-100 text-emerald-800 text-[11px] font-bold px-2.5 py-0.5 rounded-full border border-emerald-200 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                      <span>Verified Test Notice Graphic</span>
                    </span>
                    <span className="bg-sky-100 text-sky-800 text-[11px] font-bold px-2.5 py-0.5 rounded-full border border-sky-200 flex items-center gap-1">
                      <Globe className="w-3 h-3 text-sky-600" />
                      <span>Stored for All Visitors</span>
                    </span>
                    <span className="text-xs text-slate-500 font-medium hidden sm:inline">
                      (सूचना पट्ट परीक्षण छवि)
                    </span>
                  </div>
                  <h5 className="text-sm sm:text-base font-bold text-slate-900 mt-1.5">
                    {noticeBoxTestImageCaption}
                  </h5>
                </div>

                <div className="flex items-center gap-2 flex-wrap self-start sm:self-auto">
                  <button
                    type="button"
                    onClick={() => {
                      setTestImageTarget('notice-board');
                      setUploadImagePassword('');
                      setUploadImagePasswordError('');
                      setIsTestImageModalOpen(true);
                    }}
                    className="inline-flex items-center gap-1.5 text-xs font-bold px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 shadow-sm transition active:scale-95 cursor-pointer"
                    title="Upload / Test Custom Image on Notice Box (Admin Password Protected)"
                  >
                    <Lock className="w-3.5 h-3.5" />
                    <span>Upload Test Image (Admin)</span>
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      setLightboxPhoto({
                        id: 'notice-box-test-image',
                        url: noticeBoxTestImage,
                        title: noticeBoxTestImageCaption,
                        subtitle: 'Notice Box Test Image • NJS Public School Circular Graphic',
                        category: 'test',
                      })
                    }
                    className="inline-flex items-center gap-1 text-xs font-semibold px-3 py-1.5 rounded-xl bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 transition shadow-xs cursor-pointer"
                    title="View Enlarged Test Image"
                  >
                    <Maximize2 className="w-3.5 h-3.5 text-slate-600" />
                    <span>Enlarge</span>
                  </button>
                </div>
              </div>

              {/* The Notice Box Test Image Canvas */}
              <div
                className="relative rounded-2xl overflow-hidden border border-slate-200/90 shadow-md group bg-slate-950 cursor-pointer"
                onClick={() =>
                  setLightboxPhoto({
                    id: 'notice-box-test-image',
                    url: noticeBoxTestImage,
                    title: noticeBoxTestImageCaption,
                    subtitle: 'Notice Box Test Image • NJS Public School Circular Graphic',
                    category: 'test',
                  })
                }
              >
                <img
                  src={noticeBoxTestImage}
                  alt="NJS Notice Box Test Graphic"
                  className="w-full h-56 sm:h-72 md:h-80 object-cover object-center transition duration-500 group-hover:scale-[1.02]"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/20 to-transparent pointer-events-none" />
                <div className="absolute top-3 left-3 bg-slate-900/85 backdrop-blur text-white text-[11px] font-bold px-3 py-1 rounded-full border border-white/20 flex items-center gap-1.5 shadow-sm">
                  <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                  <span>Notice Box Test Attachment</span>
                </div>
                <div className="absolute bottom-3 inset-x-3 sm:inset-x-5 flex flex-col sm:flex-row sm:items-end justify-between gap-2 text-white">
                  <div>
                    <span className="text-[10px] font-mono uppercase tracking-wider text-amber-400 bg-amber-950/80 px-2 py-0.5 rounded border border-amber-500/30">
                      Test Image Bulletin
                    </span>
                    <p className="text-xs sm:text-sm text-slate-200 font-medium mt-1 leading-snug drop-shadow-sm">
                      {noticeBoxTestImageCaption}
                    </p>
                  </div>
                  <span className="bg-white/20 hover:bg-white/30 backdrop-blur px-3 py-1.5 rounded-xl text-xs font-bold text-white border border-white/30 flex items-center gap-1 self-start sm:self-auto shadow-sm">
                    <ZoomIn className="w-3.5 h-3.5" /> Enlarge (बड़ा देखें)
                  </span>
                </div>
              </div>

              {/* Quick Presets row for instant testing */}
              <div className="mt-3.5 pt-3 border-t border-indigo-100/80 flex flex-wrap items-center justify-between gap-2 text-xs">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1 mr-1">
                    <SlidersHorizontal className="w-3 h-3 text-indigo-600" /> Quick Test Presets:
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      const url = 'https://seemaanantom-eng.github.io/NJSpublicSchool/race.jpg';
                      const cap = '400m Olympic Track Sprint & Athletics Circular Preview';
                      updateNoticeBoxTestImageStateAndServer(url, cap);
                      setSuccessToast('✅ Notice box test image updated & saved to cloud: 400m Track Race');
                      setTimeout(() => setSuccessToast(''), 3000);
                    }}
                    className={`font-semibold px-2.5 py-1 rounded-lg border transition text-[11px] flex items-center gap-1 cursor-pointer ${
                      noticeBoxTestImage === 'https://seemaanantom-eng.github.io/NJSpublicSchool/race.jpg'
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                        : 'bg-white hover:bg-indigo-50 text-slate-700 border-slate-200'
                    }`}
                  >
                    🏃 400m Track
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const url = 'https://seemaanantom-eng.github.io/NJSpublicSchool/group.jpg';
                      const cap = 'NJS Public School Faculty & Student Council Bulletin';
                      updateNoticeBoxTestImageStateAndServer(url, cap);
                      setSuccessToast('✅ Notice box test image updated & saved to cloud: Campus Council');
                      setTimeout(() => setSuccessToast(''), 3000);
                    }}
                    className={`font-semibold px-2.5 py-1 rounded-lg border transition text-[11px] flex items-center gap-1 cursor-pointer ${
                      noticeBoxTestImage === 'https://seemaanantom-eng.github.io/NJSpublicSchool/group.jpg'
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                        : 'bg-white hover:bg-indigo-50 text-slate-700 border-slate-200'
                    }`}
                  >
                    👥 Campus Council
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const url = 'https://seemaanantom-eng.github.io/NJSpublicSchool/havan.jpg';
                      const cap = 'Vedic Havan Ceremony & Annual Moral Values Circular';
                      updateNoticeBoxTestImageStateAndServer(url, cap);
                      setSuccessToast('✅ Notice box test image updated & saved to cloud: Havan Ceremony');
                      setTimeout(() => setSuccessToast(''), 3000);
                    }}
                    className={`font-semibold px-2.5 py-1 rounded-lg border transition text-[11px] flex items-center gap-1 cursor-pointer ${
                      noticeBoxTestImage === 'https://seemaanantom-eng.github.io/NJSpublicSchool/havan.jpg'
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                        : 'bg-white hover:bg-indigo-50 text-slate-700 border-slate-200'
                    }`}
                  >
                    🔥 Havan Ceremony
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const url = 'https://seemaanantom-eng.github.io/NJSpublicSchool/cricket.jpg';
                      const cap = 'Inter-School Cricket Championship & Sports Fixtures';
                      updateNoticeBoxTestImageStateAndServer(url, cap);
                      setSuccessToast('✅ Notice box test image updated & saved to cloud: Cricket Championship');
                      setTimeout(() => setSuccessToast(''), 3000);
                    }}
                    className={`font-semibold px-2.5 py-1 rounded-lg border transition text-[11px] flex items-center gap-1 cursor-pointer ${
                      noticeBoxTestImage === 'https://seemaanantom-eng.github.io/NJSpublicSchool/cricket.jpg'
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                        : 'bg-white hover:bg-indigo-50 text-slate-700 border-slate-200'
                    }`}
                  >
                    🏏 Cricket Match
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const url = 'https://seemaanantom-eng.github.io/NJSpublicSchool/tree.jpg';
                      const cap = 'NJS Public School Green Campus Environment Week Bulletin';
                      updateNoticeBoxTestImageStateAndServer(url, cap);
                      setSuccessToast('✅ Notice box test image updated & saved to cloud: Green Campus');
                      setTimeout(() => setSuccessToast(''), 3000);
                    }}
                    className={`font-semibold px-2.5 py-1 rounded-lg border transition text-[11px] flex items-center gap-1 cursor-pointer ${
                      noticeBoxTestImage === 'https://seemaanantom-eng.github.io/NJSpublicSchool/tree.jpg'
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                        : 'bg-white hover:bg-indigo-50 text-slate-700 border-slate-200'
                    }`}
                  >
                    🌳 Campus View
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* ========================================================================= */}
          {/* IMAGE DISPLAY AT BOTTOM OF SCHOOL CIRCULARS & NOTIFICATIONS               */}
          {/* ========================================================================= */}
          <div className="mt-8 pt-6 border-t border-slate-200/90">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-3.5">
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="inline-flex items-center gap-1.5 bg-indigo-50 text-indigo-700 text-xs font-bold px-3 py-1 rounded-full border border-indigo-200 uppercase tracking-wide">
                    <School className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Campus Circulars & Bulletin Board</span>
                  </span>
                  <span className="text-xs text-slate-500 font-medium">
                    आधिकारिक विद्यालय सूचना पट्ट
                  </span>
                </div>
                <h4 className="text-base sm:text-lg font-bold text-slate-900 mt-1">
                  School Circulars, Sports Schedules & Convocation Notice Display
                </h4>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    setTestImageTarget('notice-board');
                    setUploadImagePassword('');
                    setUploadImagePasswordError('');
                    setIsTestImageModalOpen(true);
                  }}
                  className="inline-flex items-center gap-1.5 text-xs font-bold px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-600 text-slate-950 shadow-sm transition active:scale-95 cursor-pointer"
                  title="Upload / Change Notice Board Image (Admin Password Protected)"
                >
                  <Lock className="w-3.5 h-3.5 text-slate-950" />
                  <span>Update Board Image (Admin)</span>
                </button>
              </div>
            </div>

            <div className="relative rounded-2xl overflow-hidden border border-slate-200/90 shadow-lg group bg-slate-950">
              <img
                src={noticeBoardImage}
                alt="NJS Public School Circulars & Notice Bulletin"
                className="w-full h-64 sm:h-80 md:h-[420px] object-cover object-center transition duration-500 group-hover:scale-[1.02] cursor-pointer"
                onClick={() =>
                  setLightboxPhoto({
                    id: 'notice-board-image',
                    url: noticeBoardImage,
                    title: 'NJS Public School - Official Campus Notice Board & Circulars Display',
                    subtitle: 'Official circulars, sports schedules & academic notifications bulletin',
                    category: 'campus',
                  })
                }
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/25 to-transparent pointer-events-none" />

              <div className="absolute bottom-0 inset-x-0 p-4 sm:p-6 flex flex-col sm:flex-row sm:items-end justify-between gap-3 text-white">
                <div>
                  <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                    <span className="bg-emerald-500 text-slate-950 text-[10px] font-extrabold px-2.5 py-0.5 rounded-full uppercase tracking-wider shadow">
                      Verified Campus Bulletin
                    </span>
                    <span className="text-xs text-slate-300 font-medium">
                      NJS Public School • Creator of Knowledge
                    </span>
                  </div>
                  <p className="text-xs sm:text-sm text-slate-200 max-w-2xl leading-relaxed">
                    Main campus notice board for student circulars, 400m athletics timetables, holiday announcements, and admissions bulletins.
                  </p>
                </div>

                <div className="flex items-center gap-2 self-start sm:self-auto flex-shrink-0">
                  <button
                    type="button"
                    onClick={() =>
                      setLightboxPhoto({
                        id: 'notice-board-image',
                        url: noticeBoardImage,
                        title: 'NJS Public School - Official Campus Notice Board & Circulars Display',
                        subtitle: 'Official circulars, sports schedules & academic notifications bulletin',
                        category: 'campus',
                      })
                    }
                    className="bg-white/20 hover:bg-white/30 backdrop-blur border border-white/30 text-white text-xs font-semibold px-3.5 py-2 rounded-xl transition flex items-center gap-1.5 cursor-pointer shadow"
                  >
                    <Maximize2 className="w-3.5 h-3.5" />
                    <span>Enlarge Image</span>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* 4. PILLARS OF NJS EDUCATION */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div id="hastinapur" className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm hover:-translate-y-1 transition duration-200 border-t-4 border-t-emerald-500">
            <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center mb-4">
              <Bus className="w-6 h-6" />
            </div>
            <h4 className="font-['Playfair_Display',serif] text-xl font-bold text-slate-900 mb-2">
              Hastinapur Excursion
            </h4>
            <p className="text-slate-600 text-sm leading-relaxed">
              Curated educational trips to historic Hastinapur antiquities (Kuru Empire remnants & sacred Jain temples) with 24/7 faculty supervision and buffet meals.
            </p>
          </div>

          <div id="sports" className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm hover:-translate-y-1 transition duration-200 border-t-4 border-t-indigo-500">
            <div className="w-12 h-12 rounded-2xl bg-indigo-100 text-indigo-700 flex items-center justify-center mb-4">
              <Trophy className="w-6 h-6" />
            </div>
            <h4 className="font-['Playfair_Display',serif] text-xl font-bold text-slate-900 mb-2">
              400m Olympic Track
            </h4>
            <p className="text-slate-600 text-sm leading-relaxed">
              Full-sized athletics facilities including 400-meter all-weather track, basketball courts, and FIFA-standard turf for athletics trials and championships.
            </p>
          </div>

          <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm hover:-translate-y-1 transition duration-200 border-t-4 border-t-amber-500">
            <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-700 flex items-center justify-center mb-4">
              <Palette className="w-6 h-6" />
            </div>
            <h4 className="font-['Playfair_Display',serif] text-xl font-bold text-slate-900 mb-2">
              Clay Sculpting & Pottery
            </h4>
            <p className="text-slate-600 text-sm leading-relaxed">
              Tactile ceramic and pottery workshops using terracotta and stoneware clay for creative fine arts expression and cultural heritage connection.
            </p>
          </div>
        </section>

        {/* ========================================================================= */}
        {/* DIRECT CONTENT FROM https://seemaanantom-eng.github.io/NJSpublicSchool/    */}
        {/* ========================================================================= */}
        <section id="official-original-content" className="mt-14 pt-10 border-t-2 border-slate-300">
          <div className="text-center mb-8">
            <span className="inline-block bg-slate-900 text-emerald-400 font-mono text-xs uppercase px-4 py-1.5 rounded-full font-bold shadow-sm">
              Official Campus Archives • seemaanantom-eng.github.io/NJSpublicSchool
            </span>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-slate-900 mt-3 font-['Playfair_Display',serif]">
              NJS Public School Campus Infrastructure & Activities
            </h2>
            <p className="text-sm sm:text-base text-slate-600 mt-1 max-w-2xl mx-auto">
              Original website content, architectural stabilizers, campus sports infrastructure, Hastinapur educational excursions, and student achievements.
            </p>
          </div>

          {/* 1. NJS Glass Banner */}
          <div id="njs-banner-section" className="rounded-3xl overflow-hidden shadow-xl mb-8">
            <div className="njs-glass-card">
              <h1 className="njs-school-name">NJS Public School</h1>
              <p className="njs-tagline">Excellence in Education & Innovation</p>
              <div className="njs-stabilizer-bar"></div>
            </div>
          </div>

          {/* 2. Creator of Knowledge & Emblem */}
          <div className="creator-container">
            <p className="knowledge-creator">Creator of Knowledge</p>
          </div>
          <div className="relative inline-block w-full text-center">
            <img
              id="apple"
              src={customLogoImage || 'https://seemaanantom-eng.github.io/NJSpublicSchool/apple.jpg'}
              alt="NJS Public School Apple Emblem"
              className="w-40 h-40 object-cover mx-auto rounded-2xl shadow-xl border-4 border-white my-6 cursor-pointer hover:scale-105 transition"
              onClick={() =>
                setLightboxPhoto({
                  id: 'emblem-view',
                  url: customLogoImage || 'https://seemaanantom-eng.github.io/NJSpublicSchool/apple.jpg',
                  title: 'NJS Public School Apple Emblem',
                  subtitle: customLogoImage ? 'Custom Test Emblem Active' : 'Official Apple Emblem • Creator of Knowledge',
                  category: 'campus',
                  isTest: !!customLogoImage,
                })
              }
            />
            {customLogoImage && (
              <div className="text-center -mt-3 mb-4">
                <span className="text-[11px] bg-amber-100 text-amber-900 font-bold px-3 py-1 rounded-full border border-amber-300 inline-flex items-center gap-1.5 shadow-sm">
                  <FlaskConical className="w-3.5 h-3.5 text-amber-600" />
                  <span>Custom Emblem Test Active</span>
                  <button
                    onClick={() => setCustomLogoImage(null)}
                    className="ml-1 text-slate-600 hover:text-red-600 underline font-semibold"
                    title="Revert to official Apple emblem"
                  >
                    Reset
                  </button>
                </span>
              </div>
            )}
          </div>

          {/* 3. Stabilizer Architecture Text */}
          <p className="stabilizer-text">
            In the architectural and structural design of a school building, the{' '}
            <strong>stabilizer</strong> refers to the core elements that ensure the safety and longevity of the facility against physical stresses. This typically involves a combination of reinforced concrete shear walls and a robust foundation system designed to resist lateral forces like high winds or seismic activity.
          </p>

          {/* 4. Mega Slider 1: Life at NJS Public School */}
          <div className="mega-slider-stage my-10 bg-white p-6 rounded-3xl border border-slate-200 shadow-md">
            <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
              <h3 className="section-title text-xl sm:text-2xl font-bold text-slate-900 font-['Playfair_Display',serif]">
                Life at NJS Public School
              </h3>
              <span className="text-xs text-slate-400 font-semibold">
                Slide {megaIndex1 + 1} of {megaSlides1.length}
              </span>
            </div>

            <div className="slider-container relative overflow-hidden rounded-2xl bg-slate-950 aspect-[16/9] sm:aspect-[21/9] flex items-center justify-center">
              <img
                src={megaSlides1[megaIndex1].img}
                alt={megaSlides1[megaIndex1].alt}
                className="w-full h-full object-cover transition-all duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent flex flex-col justify-end p-4 sm:p-6 text-white">
                <span className="text-emerald-400 font-bold text-xs uppercase tracking-wider mb-1">
                  {megaSlides1[megaIndex1].title}
                </span>
                <p className="text-xs sm:text-sm text-slate-200 max-w-xl">
                  {megaSlides1[megaIndex1].caption}
                </p>
              </div>

              {/* Prev / Next buttons */}
              <button
                type="button"
                onClick={() => moveMega1(-1)}
                className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/80 hover:bg-white text-slate-900 shadow-lg flex items-center justify-center text-lg font-bold transition hover:scale-110 active:scale-95"
                title="Previous slide"
              >
                ❮
              </button>
              <button
                type="button"
                onClick={() => moveMega1(1)}
                className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/80 hover:bg-white text-slate-900 shadow-lg flex items-center justify-center text-lg font-bold transition hover:scale-110 active:scale-95"
                title="Next slide"
              >
                ❯
              </button>
            </div>

            {/* Slider Dots */}
            <div className="flex justify-center gap-2 mt-4">
              {megaSlides1.map((_, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setMegaIndex1(i)}
                  className={`h-2.5 rounded-full transition-all ${
                    megaIndex1 === i ? 'w-8 bg-emerald-600' : 'w-2.5 bg-slate-200'
                  }`}
                  aria-label={`Slide ${i + 1}`}
                />
              ))}
            </div>
          </div>

          {/* 5. Campus Sports Infrastructure (.sf-project-wrapper) */}
          <section className="sf-project-wrapper">
            <div className="sf-project-banner">
              <h2>Campus Sports Infrastructure</h2>
            </div>
            <div className="sf-project-body">
              <p>
                The <span className="sf-project-highlight">sports facilities</span> at our institution are designed to bridge the gap between amateur recreation and professional athletic training. By integrating high-end equipment with expansive outdoor arenas, we provide a sanctuary for physical health and mental clarity. Our facilities include a weather-resistant 400-meter track, multi-sport courts for basketball and tennis, and a specialized aquatic wing. These spaces are more than just physical assets; they are the heart of our community where students cultivate <span className="sf-project-highlight">leadership</span>, teamwork, and the discipline required to excel in both sports and academics. Every surface, from the low-impact gym flooring to the floodlit football turf, is maintained to the highest safety standards to ensure an injury-free environment for all participants.
              </p>
            </div>
            <div className="sf-project-features">
              <span className="sf-feature-tag">Indoor Arena</span>
              <span className="sf-feature-tag">Olympic Pool</span>
              <span className="sf-feature-tag">Fitness Lab</span>
            </div>
          </section>

          {/* 6. Group Photo Showcase */}
          <div className="my-8 text-center">
            <img
              id="noni"
              src="https://seemaanantom-eng.github.io/NJSpublicSchool/group.jpg"
              alt="NJS Students Group"
              className="rounded-2xl shadow-xl max-w-lg w-full mx-auto border-4 border-white"
            />
          </div>

          {/* 7. Educational Excursion: Hastinapur (.trip-module) */}
          <div className="trip-module">
            <header className="trip-header">
              <h2>Educational Excursion: Hastinapur</h2>
            </header>
            <div className="trip-content">
              The school is proud to announce an upcoming excursion to the ancient city of <span className="trip-highlight">Hastinapur</span>, a site of immense historical and cultural significance. This trip is designed to offer students a firsthand look at the remnants of the Kuru Empire and the rich spiritual heritage of the Jain temples. To ensure a seamless experience, the school has organized top-tier <span className="trip-highlight">trip facilities</span>, including secure transportation in certified tourist buses, healthy buffet-style meals, and accommodation in vetted hospitality partners. Our itinerary balances educational lectures at historical sites with recreational visits to the local wildlife sanctuary, all under the vigilant supervision of our senior teaching staff and on-site medical coordinators.
            </div>
            <div className="facilities-bar">
              <div className="facility-item">✓ Certified Transport</div>
              <div className="facility-item">✓ 24/7 Supervision</div>
              <div className="facility-item">✓ Medical Support</div>
              <div className="facility-item">✓ Guided Tours</div>
            </div>
          </div>

          {/* 8. Mega Slider 2: Our Achievements */}
          <div className="mega-slider-stage-2 my-10 bg-white p-6 rounded-3xl border border-slate-200 shadow-md">
            <div className="flex items-center justify-between mb-4 pb-2 border-b border-slate-100">
              <h3 className="section-title text-xl sm:text-2xl font-bold text-slate-900 font-['Playfair_Display',serif]">
                Our Achievements
              </h3>
              <span className="text-xs text-slate-400 font-semibold">
                Slide {megaIndex2 + 1} of {megaSlides2.length}
              </span>
            </div>

            <div className="slider-container-2 relative overflow-hidden rounded-2xl bg-slate-950 aspect-[16/9] sm:aspect-[21/9] flex items-center justify-center">
              <img
                src={megaSlides2[megaIndex2].img}
                alt={megaSlides2[megaIndex2].alt}
                className="w-full h-full object-cover transition-all duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent flex flex-col justify-end p-4 sm:p-6 text-white">
                <span className="text-amber-400 font-bold text-xs uppercase tracking-wider mb-1">
                  {megaSlides2[megaIndex2].title}
                </span>
                <p className="text-xs sm:text-sm text-slate-200 max-w-xl">
                  {megaSlides2[megaIndex2].caption}
                </p>
              </div>

              {/* Prev / Next buttons */}
              <button
                type="button"
                onClick={() => moveMega2(-1)}
                className="absolute left-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/80 hover:bg-white text-slate-900 shadow-lg flex items-center justify-center text-lg font-bold transition hover:scale-110 active:scale-95"
                title="Previous slide"
              >
                ❮
              </button>
              <button
                type="button"
                onClick={() => moveMega2(1)}
                className="absolute right-3 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/80 hover:bg-white text-slate-900 shadow-lg flex items-center justify-center text-lg font-bold transition hover:scale-110 active:scale-95"
                title="Next slide"
              >
                ❯
              </button>
            </div>

            {/* Slider Dots */}
            <div className="flex justify-center gap-2 mt-4">
              {megaSlides2.map((_, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setMegaIndex2(i)}
                  className={`h-2.5 rounded-full transition-all ${
                    megaIndex2 === i ? 'w-8 bg-amber-500' : 'w-2.5 bg-slate-200'
                  }`}
                  aria-label={`Slide ${i + 1}`}
                />
              ))}
            </div>
          </div>

          {/* 9. Creative & Extra-Curricular Life Activity Block */}
          <article className="activity-block">
            <header className="activity-banner">
              <h2>Creative & Extra-Curricular Life</h2>
            </header>
            <div className="activity-text">
              The school’s commitment to a well-rounded education is best seen through our immersive <b>clay activities</b> and diverse club offerings. In our pottery workshops, students engage in the meditative practice of sculpting, using high-quality terracotta and stoneware clay to bring their imaginations to life. This tactile experience is complemented by a wide array of <b>other activities</b>, ranging from high-energy sports tournaments to intellectual debates and cultural festivals. By participating in these programs, students learn to step outside their comfort zones, fostering a spirit of innovation and resilience. Whether they are perfecting a glaze in the kiln room or programming a robot for a regional competition, our students are constantly encouraged to explore, create, and lead.
            </div>
            <footer className="activity-footer">
              <span className="activity-tag">Pottery & Ceramics</span>
              <span className="activity-tag">Robotics Lab</span>
              <span className="activity-tag">Drama Society</span>
              <span className="activity-tag">Music Academy</span>
              <span className="activity-tag">Eco-Warriors</span>
            </footer>
          </article>

          {/* 10. Photo Gallery Section (with dynamic test image support) */}
          <section id="community-gallery" className="photo-gallery-section scroll-mt-24">
            <div className="gallery-header">
              <h2>Our Community & Campus Moments</h2>
              <p>Capturing the vibrant moments that define our journey together.</p>
              <div className="header-line"></div>

              {/* Gallery Controls & Test Image Trigger */}
              <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={() => setIsTestImageModalOpen(true)}
                  className="bg-slate-900 hover:bg-slate-800 text-amber-300 font-bold text-xs sm:text-sm px-5 py-2.5 rounded-2xl shadow-md transition flex items-center gap-2 border border-amber-400/30 hover:scale-105 active:scale-95"
                >
                  <ImagePlus className="w-4 h-4 text-amber-400" />
                  <span>Add Any Image for Test (छवि जोड़ें)</span>
                </button>

                {galleryPhotos.some((p) => p.isTest) && (
                  <button
                    type="button"
                    onClick={handleResetGallery}
                    className="bg-white hover:bg-slate-100 text-slate-700 font-semibold text-xs sm:text-sm px-4 py-2.5 rounded-2xl shadow-sm border border-slate-300 transition flex items-center gap-1.5"
                    title="Remove all test images and restore default school photos"
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
                    <span>Reset to Defaults</span>
                  </button>
                )}

                <span className="text-xs text-slate-700 font-medium bg-white/70 backdrop-blur px-3 py-1.5 rounded-full border border-slate-200">
                  {galleryPhotos.length} Photos {galleryPhotos.filter((p) => p.isTest).length > 0 && `(${galleryPhotos.filter((p) => p.isTest).length} in Test Mode)`}
                </span>
              </div>
            </div>

            <div className="photo-grid">
              {galleryPhotos.map((photo) => {
                const aspectClass = photo.aspect === 'tall' ? 'tall' : photo.aspect === 'wide' ? 'wide' : '';
                const filterClass =
                  photo.filter === 'vivid'
                    ? 'photo-filter-vivid'
                    : photo.filter === 'grayscale'
                    ? 'photo-filter-grayscale'
                    : photo.filter === 'warm'
                    ? 'photo-filter-warm'
                    : photo.filter === 'cool'
                    ? 'photo-filter-cool'
                    : '';

                return (
                  <div
                    key={photo.id}
                    className={`photo-item ${aspectClass} group cursor-pointer relative`}
                    onClick={() => setLightboxPhoto(photo)}
                  >
                    <img
                      src={photo.url}
                      alt={photo.title}
                      className={`${filterClass} transition duration-300`}
                    />

                    {/* Test Image Badge */}
                    {photo.isTest && (
                      <div className="absolute top-2.5 left-2.5 z-10 flex items-center gap-1 bg-amber-500 text-slate-950 font-extrabold text-[10px] uppercase tracking-wider px-2 py-0.5 rounded-full shadow-md border border-white">
                        <FlaskConical className="w-3 h-3" />
                        <span>TEST IMAGE</span>
                      </div>
                    )}

                    {/* Quick Delete for Test Images */}
                    {photo.isTest && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleRemovePhoto(photo.id, photo.title);
                        }}
                        className="absolute top-2.5 right-2.5 z-10 bg-slate-900/80 hover:bg-red-600 text-white p-1.5 rounded-full shadow transition"
                        title="Delete test image from gallery"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}

                    {/* Photo Info Overlay */}
                    <div className="photo-overlay">
                      <div className="w-full">
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-white text-sm sm:text-base">{photo.title}</span>
                          <ZoomIn className="w-4 h-4 text-emerald-400 opacity-80" />
                        </div>
                        {photo.subtitle && (
                          <p className="text-slate-300 text-xs mt-0.5 line-clamp-1">
                            {photo.subtitle}
                          </p>
                        )}
                        {photo.dimensions && (
                          <span className="text-[10px] text-amber-300 font-mono mt-1 inline-block">
                            {photo.dimensions} {photo.fileSize && `• ${photo.fileSize}`}
                          </span>
                        )}

                        {/* Make Notice Box Test Image Action Button */}
                        <div className="mt-2 pt-2 border-t border-white/15 flex items-center justify-between gap-2">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              updateNoticeBoxTestImageStateAndServer(photo.url, photo.title);
                              setSuccessToast(`✅ Notice Box Test Image set to: "${photo.title}" (Saved to Cloud)`);
                              setTimeout(() => setSuccessToast(''), 4000);
                              const el = document.getElementById('notices');
                              if (el) el.scrollIntoView({ behavior: 'smooth' });
                            }}
                            className={`inline-flex items-center gap-1.5 text-[11px] font-bold px-2.5 py-1 rounded-lg transition shadow-xs cursor-pointer ${
                              noticeBoxTestImage === photo.url
                                ? 'bg-emerald-500 text-slate-950 ring-2 ring-emerald-300 font-extrabold'
                                : 'bg-amber-500 hover:bg-amber-400 text-slate-950 active:scale-95'
                            }`}
                            title="Make this image the Notice Box Test Image (सूचना पट्ट में लगाएं)"
                          >
                            <FlaskConical className="w-3.5 h-3.5 text-slate-950" />
                            <span>{noticeBoxTestImage === photo.url ? '✓ Notice Box Active' : 'Make Notice Box Test Image'}</span>
                          </button>
                          <span className="text-[10px] text-slate-300 font-medium">Click to zoom</span>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          {/* 11. Simple Footer from original page */}
          <div className="simple-footer rounded-2xl border border-slate-200 mt-6 shadow-sm">
            <div className="footer-wrap">
              <div className="footer-brand">NJS PUBLIC SCHOOL</div>
              <nav className="footer-links">
                <a href="#about" className="text-slate-600 hover:text-indigo-600">About</a>
                <a href="#sports" className="text-slate-600 hover:text-indigo-600">Sports & Track</a>
                <a href="#notices" className="text-slate-600 hover:text-indigo-600">Admissions</a>
              </nav>
              <div className="footer-copy text-sm text-slate-500">
                &copy; 2026 | <span className="highlight font-bold text-emerald-600">Creator of Knowledge</span>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* FOOTER */}
      <footer className="bg-slate-950 text-slate-400 pt-10 pb-28 sm:pb-12 px-4 border-t border-slate-800 text-sm">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6 text-center md:text-left">
          <div>
            <div className="font-['Playfair_Display',serif] text-lg font-bold text-white">
              NJS PUBLIC SCHOOL
            </div>
            <p className="text-xs text-slate-400 mt-1">
              Official Portal & AI Assistant • Creator of Knowledge
            </p>
          </div>

          <div className="flex flex-wrap items-center justify-center gap-5 text-xs">
            <a
              href="https://seemaanantom-eng.github.io/NJSpublicSchool/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-sky-400 hover:underline flex items-center gap-1"
            >
              <span>seemaanantom-eng.github.io/NJSpublicSchool</span>
              <ExternalLink className="w-3 h-3" />
            </a>
            <span>•</span>
            <a
              href="https://www.youtube.com/@anantgahlaut"
              target="_blank"
              rel="noopener noreferrer"
              className="text-red-400 hover:underline flex items-center gap-1"
            >
              <Youtube className="w-3.5 h-3.5" />
              <span>@anantgahlaut</span>
            </a>
            <span>•</span>
            <button
              onClick={() => setIsDownloadModalOpen(true)}
              className="text-sky-400 hover:underline flex items-center gap-1 font-semibold"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download File (.html)</span>
            </button>
            <span>•</span>
            <button
              onClick={handleDownloadProspectus}
              className="text-emerald-400 hover:underline flex items-center gap-1"
            >
              <FileDown className="w-3.5 h-3.5" />
              <span>Download Prospectus</span>
            </button>
          </div>

          <div className="text-xs text-slate-400">
            &copy; 2026 NJS Public School. All rights reserved.
          </div>
        </div>

        {/* Prominent Official Link Banner at Bottom */}
        <div className="max-w-7xl mx-auto mt-8 pt-6 border-t border-slate-800 flex flex-col md:flex-row items-center justify-between gap-4 bg-slate-900/90 p-4 sm:p-5 rounded-2xl border border-slate-800 text-center md:text-left">
          <div className="space-y-1">
            <div className="text-xs font-bold text-sky-400 uppercase tracking-wider flex items-center gap-1.5 justify-center md:justify-start">
              <Globe className="w-4 h-4 text-emerald-400" />
              <span>Official School Repository & Source:</span>
            </div>
            <a
              href="https://seemaanantom-eng.github.io/NJSpublicSchool/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-base sm:text-lg font-bold text-emerald-400 hover:text-emerald-300 underline break-all inline-flex items-center gap-1.5"
            >
              <span>https://seemaanantom-eng.github.io/NJSpublicSchool/</span>
              <ExternalLink className="w-4 h-4 flex-shrink-0" />
            </a>
            <p className="text-xs text-slate-400">
              Original website source with event photos, havan ceremonies, faculty mentorship, and school records.
            </p>
          </div>

          <div className="flex items-center gap-2.5 flex-shrink-0">
            <a
              href="https://seemaanantom-eng.github.io/NJSpublicSchool/"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-sky-600 hover:bg-sky-500 text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-xl transition flex items-center gap-2 shadow-md shadow-sky-600/20"
            >
              <span>Open Link</span>
              <ExternalLink className="w-4 h-4" />
            </a>

            <button
              onClick={() => {
                navigator.clipboard.writeText('https://seemaanantom-eng.github.io/NJSpublicSchool/');
                setSuccessToast('Link copied: https://seemaanantom-eng.github.io/NJSpublicSchool/');
                setTimeout(() => setSuccessToast(''), 3000);
              }}
              className="bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 font-semibold text-xs sm:text-sm px-3.5 py-2.5 rounded-xl transition flex items-center gap-1.5"
              title="Copy official website link"
            >
              <Copy className="w-4 h-4" />
              <span>Copy</span>
            </button>
          </div>
        </div>
      </footer>

      {/* MOBILE BOTTOM NAVIGATION BAR (Sticky for quick access on mobile phones) */}
      <nav
        aria-label="Mobile Navigation"
        className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 px-3 py-1.5 flex justify-around items-center shadow-lg safe-area-pb"
      >
        <a
          href="#about"
          className="flex flex-col items-center gap-0.5 text-slate-600 hover:text-emerald-600 text-[10px] font-semibold py-1 px-2 transition"
        >
          <Home className="w-5 h-5 text-slate-600" />
          <span>Home</span>
        </a>

        <a
          href="#notices"
          className="flex flex-col items-center gap-0.5 text-slate-600 hover:text-indigo-600 text-[10px] font-semibold py-1 px-2 relative transition"
        >
          <Bell className="w-5 h-5 text-slate-600" />
          <span>Notices</span>
          {notices.length > 0 && (
            <span className="absolute top-0.5 right-1 bg-emerald-600 text-white text-[9px] w-4 h-4 rounded-full flex items-center justify-center font-bold">
              {notices.length}
            </span>
          )}
        </a>

        {/* Center Prominent Ask AI Button */}
        <button
          onClick={() => setIsAiDrawerOpen(true)}
          className="-mt-5 bg-gradient-to-r from-emerald-500 to-teal-600 text-white p-3 rounded-full shadow-lg shadow-emerald-500/30 border-2 border-white flex flex-col items-center justify-center hover:scale-105 active:scale-95 transition"
          title="Open AI School Assistant"
        >
          <Sparkles className="w-5 h-5 animate-pulse" />
        </button>

        <button
          onClick={() => setIsDownloadModalOpen(true)}
          className="flex flex-col items-center gap-0.5 text-slate-600 hover:text-sky-600 text-[10px] font-semibold py-1 px-2 transition"
          title="Download School Files & Portal"
        >
          <Download className="w-5 h-5 text-sky-600" />
          <span>Download</span>
        </button>

        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="flex flex-col items-center gap-0.5 text-slate-600 hover:text-emerald-600 text-[10px] font-semibold py-1 px-2 transition"
        >
          <Menu className="w-5 h-5 text-slate-600" />
          <span>Menu</span>
        </button>
      </nav>

      {/* FLOATING ACTION BUTTON (AI FAB) */}
      <button
        onClick={() => setIsAiDrawerOpen(!isAiDrawerOpen)}
        className="fixed bottom-20 sm:bottom-6 right-4 sm:right-6 w-13 h-13 sm:w-14 sm:h-14 rounded-full bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-2xl flex items-center justify-center hover:scale-105 active:scale-95 transition z-40 border-2 border-white/80"
        title="NJS School AI Assistant"
      >
        <Sparkles className="w-6 h-6 animate-pulse" />
        <span className="absolute -top-1 -right-1 bg-red-600 text-white text-[10px] font-bold px-1.5 py-0.5 rounded-full border-2 border-white">
          AI
        </span>
      </button>

      {/* FLOATING AI CHAT DRAWER (Inspired by 24/7 International School AI Program) */}
      {isAiDrawerOpen && (
        <div className="fixed inset-x-0 bottom-0 sm:inset-x-auto sm:bottom-24 sm:right-6 w-full sm:w-[440px] h-[88vh] sm:h-[600px] max-h-[92vh] bg-white rounded-t-3xl sm:rounded-3xl shadow-2xl border-t sm:border border-slate-200 z-50 flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom duration-200">
          {/* Mobile Sheet Pull Bar */}
          <div className="sm:hidden pt-2.5 pb-1 bg-slate-900 flex justify-center">
            <div className="w-12 h-1 bg-slate-600 rounded-full" />
          </div>

          {/* Chat Header */}
          <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-emerald-950 text-white p-3.5 sm:p-4 flex items-center justify-between border-b border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/40">
                <Sparkles className="w-5 h-5 animate-pulse" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h4 className="font-bold text-sm text-emerald-300">
                    Ask AI
                  </h4>
                  <span className="flex items-center gap-1 bg-emerald-500/20 text-emerald-300 text-[10px] font-semibold px-2 py-0.5 rounded-full border border-emerald-500/30">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                    24/7 Live
                  </span>
                </div>
                <p className="text-[11px] text-slate-400">
                  Virtual School Assistant • NJS Public School
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {/* Multilingual Switcher Dropdown */}
              <div className="relative inline-flex items-center bg-slate-800/90 border border-slate-700 rounded-xl px-2 py-1 text-xs text-slate-200">
                <Languages className="w-3.5 h-3.5 text-emerald-400 mr-1.5 flex-shrink-0" />
                <select
                  value={selectedLanguage}
                  onChange={(e) => setSelectedLanguage(e.target.value as any)}
                  className="bg-transparent text-[11px] font-semibold text-slate-200 focus:outline-none cursor-pointer"
                  title="Switch Language (Ask AI Multilingual Program)"
                >
                  <option value="English" className="text-slate-900 bg-white">English</option>
                  <option value="Hindi" className="text-slate-900 bg-white">हिन्दी (Hindi)</option>
                  <option value="Hinglish" className="text-slate-900 bg-white">Hinglish</option>
                  <option value="Deutsch" className="text-slate-900 bg-white">Deutsch (German)</option>
                  <option value="Français" className="text-slate-900 bg-white">Français (French)</option>
                  <option value="Español" className="text-slate-900 bg-white">Español (Spanish)</option>
                </select>
              </div>

              <button
                onClick={() => setIsAiDrawerOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition"
                title="Close Assistant"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Quick Context & Ticket Quick Launch Bar */}
          <div className="bg-slate-100 px-3.5 py-1.5 text-[11px] text-slate-600 flex items-center justify-between border-b border-slate-200">
            <span className="flex items-center gap-1.5">
              <span className={`w-2 h-2 rounded-full ${activeHolidayNotice ? 'bg-amber-500' : 'bg-emerald-500'}`} />
              <strong>{activeHolidayNotice ? 'Holiday Declared' : 'School is OPEN'}</strong>
            </span>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setIsInquiryModalOpen(true)}
                className="text-emerald-700 font-bold hover:underline flex items-center gap-1 bg-emerald-50 px-2 py-0.5 rounded-lg border border-emerald-200"
                title="Submit Parent Inquiry / Request Callback"
              >
                <FileText className="w-3 h-3" />
                <span>Inquiry Ticket</span>
              </button>

              <button
                onClick={() => {
                  setPasswordError('');
                  setIsModalOpen(true);
                }}
                className="text-indigo-600 font-bold hover:underline flex items-center gap-1"
                title="Add Official Notice (Admin Only)"
              >
                <KeyRound className="w-3 h-3" />
                <span>Notice</span>
              </button>
            </div>
          </div>

          {/* Messages Container */}
          <div ref={chatScrollRef} className="flex-1 p-3.5 sm:p-4 overflow-y-auto space-y-3 bg-slate-50 text-sm">
            {chatMessages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${
                  msg.sender === 'user' ? 'items-end' : 'items-start'
                }`}
              >
                <div
                  className={`max-w-[90%] p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed whitespace-pre-line relative group ${
                    msg.sender === 'user'
                      ? 'bg-emerald-600 text-white rounded-br-sm shadow-sm'
                      : 'bg-white text-slate-800 border border-slate-200 shadow-sm rounded-bl-sm'
                  }`}
                >
                  {msg.text}

                  {/* Read aloud TTS button for bot messages */}
                  {msg.sender === 'bot' && (
                    <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
                      <button
                        onClick={() => speakText(msg.text, msg.id)}
                        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[10px] font-semibold transition ${
                          speakingId === msg.id
                            ? 'bg-emerald-100 text-emerald-800 animate-pulse'
                            : 'text-slate-500 hover:bg-slate-100'
                        }`}
                        title="Listen to response (Text-to-Speech)"
                      >
                        {speakingId === msg.id ? (
                          <>
                            <VolumeX className="w-3 h-3 text-emerald-600" />
                            <span>Stop Audio</span>
                          </>
                        ) : (
                          <>
                            <Volume2 className="w-3 h-3" />
                            <span>Listen</span>
                          </>
                        )}
                      </button>

                      <span className="text-[10px] text-slate-400">
                        {msg.timestamp}
                      </span>
                    </div>
                  )}
                </div>

                {msg.sender === 'user' && (
                  <span className="text-[10px] text-slate-400 mt-0.5 px-1">
                    {msg.timestamp}
                  </span>
                )}
              </div>
            ))}

            {isAiThinking && (
              <div className="flex items-center gap-2 text-slate-500 text-xs bg-white p-3 rounded-2xl border border-slate-200 w-fit">
                <span className="w-3.5 h-3.5 border-2 border-emerald-600 border-t-transparent rounded-full animate-spin" />
                <span>Ask AI is checking school records...</span>
              </div>
            )}
          </div>

          {/* Ask AI Topic Action Cards (FIS Ask AI Framework) */}
          <div className="px-3 py-2 bg-slate-50 border-t border-slate-200">
            <div className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1 flex items-center justify-between">
              <span>Quick Topics & Inquiries</span>
              <span className="text-emerald-700 font-semibold">{selectedLanguage}</span>
            </div>

            <div className="flex gap-1.5 overflow-x-auto pb-1 text-[11px]">
              <button
                onClick={() => handleSendChatMessage('क्या कोई नया नोटिस आया है?')}
                className="whitespace-nowrap bg-emerald-100 hover:bg-emerald-200 text-emerald-900 font-bold px-2.5 py-1 rounded-full border border-emerald-300 transition flex items-center gap-1"
              >
                <span>📢 क्या कोई नया नोटिस आया है?</span>
              </button>

              <button
                onClick={() => handleSendChatMessage('New message?')}
                className="whitespace-nowrap bg-emerald-100 hover:bg-emerald-200 text-emerald-900 font-bold px-2.5 py-1 rounded-full border border-emerald-300 transition"
              >
                💬 New message?
              </button>

              <button
                onClick={() => handleSendChatMessage('How do I apply for admissions at NJS Public School?')}
                className="whitespace-nowrap bg-white hover:bg-indigo-50 hover:text-indigo-700 text-slate-700 px-2.5 py-1 rounded-full border border-slate-200 transition font-medium flex items-center gap-1"
              >
                <GraduationCap className="w-3.5 h-3.5 text-indigo-600" />
                <span>Admissions FAQ</span>
              </button>

              <button
                onClick={() => setIsInquiryModalOpen(true)}
                className="whitespace-nowrap bg-amber-50 hover:bg-amber-100 text-amber-800 font-bold px-2.5 py-1 rounded-full border border-amber-200 transition flex items-center gap-1"
              >
                <FileText className="w-3.5 h-3.5 text-amber-600" />
                <span>Submit Inquiry Ticket</span>
              </button>

              <button
                onClick={() => handleSendChatMessage('Is school open tomorrow?')}
                className="whitespace-nowrap bg-white hover:bg-emerald-50 hover:text-emerald-700 text-slate-700 px-2.5 py-1 rounded-full border border-slate-200 transition"
              >
                Is school open?
              </button>

              <button
                onClick={() => handleSendChatMessage('Tell me about the 400m Olympic Sports Track and athletics facilities')}
                className="whitespace-nowrap bg-white hover:bg-indigo-50 hover:text-indigo-700 text-slate-700 px-2.5 py-1 rounded-full border border-slate-200 transition"
              >
                🏃 400m Track
              </button>

              <button
                onClick={() => handleSendChatMessage('Tell me about the Hastinapur educational tour')}
                className="whitespace-nowrap bg-white hover:bg-emerald-50 hover:text-emerald-700 text-slate-700 px-2.5 py-1 rounded-full border border-slate-200 transition"
              >
                🚌 Hastinapur Tour
              </button>

              <button
                onClick={() => handleSendChatMessage('What are the school timings and daily schedule?')}
                className="whitespace-nowrap bg-white hover:bg-slate-100 text-slate-700 px-2.5 py-1 rounded-full border border-slate-200 transition"
              >
                ⏰ Timings
              </button>
            </div>
          </div>

          {/* Chat Input Bar */}
          <div className="p-2.5 sm:p-3 bg-white border-t border-slate-200 flex gap-2 items-center">
            <button
              onClick={() => setIsInquiryModalOpen(true)}
              className="bg-slate-100 hover:bg-emerald-50 text-slate-700 hover:text-emerald-700 p-2 rounded-xl transition flex-shrink-0"
              title="Open Parent Inquiry & Callback Desk"
            >
              <FileText className="w-4 h-4" />
            </button>

            <input
              type="text"
              value={chatInput}
              onChange={(e) => setChatInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSendChatMessage()}
              placeholder={`Ask AI anything in ${selectedLanguage} (e.g. 'Admissions', 'Kal holiday hai?')...`}
              className="flex-1 bg-slate-100 border border-slate-200 rounded-xl px-3.5 py-2 text-xs sm:text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:border-emerald-500"
            />

            <button
              onClick={() => handleSendChatMessage()}
              disabled={!chatInput.trim()}
              className="bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white w-9 h-9 rounded-xl flex items-center justify-center transition flex-shrink-0 shadow-md shadow-emerald-600/20"
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* PARENT INQUIRY & CALLBACK TICKET MODAL (24/7 Ask AI Program Capability)   */}
      {/* ========================================================================= */}
      {isInquiryModalOpen && (
        <div className="fixed inset-0 z-[9995] bg-slate-950/75 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-white rounded-t-3xl sm:rounded-3xl max-w-lg w-full p-5 sm:p-7 shadow-2xl border border-slate-200 relative max-h-[92vh] flex flex-col overflow-y-auto">
            {/* Mobile Drag Indicator */}
            <div className="sm:hidden flex justify-center pb-2">
              <div className="w-12 h-1 bg-slate-300 rounded-full" />
            </div>

            {/* Modal Header */}
            <div className="flex items-center justify-between pb-3.5 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center border border-emerald-200">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-['Playfair_Display',serif] text-xl font-bold text-slate-900">
                    Ask AI • Parent Inquiry Desk
                  </h3>
                  <p className="text-xs text-slate-500">
                    24/7 Virtual Admissions & Parent Inquiry Ticket System
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsInquiryModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Toggle Active Tickets View */}
            <div className="mt-3 flex items-center justify-between bg-slate-50 p-2 rounded-xl text-xs border border-slate-200">
              <span className="text-slate-600 font-medium">
                Registered Inquiries: <strong>{submittedTickets.length}</strong>
              </span>
              {submittedTickets.length > 0 && (
                <button
                  type="button"
                  onClick={() => setShowInquiryHistory(!showInquiryHistory)}
                  className="text-emerald-700 font-bold hover:underline"
                >
                  {showInquiryHistory ? 'Back to Form' : 'View My Tickets'}
                </button>
              )}
            </div>

            {showInquiryHistory && submittedTickets.length > 0 ? (
              <div className="mt-4 space-y-3 max-h-[60vh] overflow-y-auto pr-1">
                <div className="flex justify-between items-center pb-1">
                  <span className="text-xs text-slate-500 font-semibold">Your Registered Inquiries</span>
                  <button
                    type="button"
                    onClick={handleDownloadTicketsCSV}
                    className="text-xs text-sky-700 font-bold hover:underline inline-flex items-center gap-1"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>Download All (.csv)</span>
                  </button>
                </div>
                {submittedTickets.map((t) => (
                  <div key={t.ticketId} className="p-3.5 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1.5">
                    <div className="flex justify-between items-center font-bold text-slate-900">
                      <span className="font-mono text-emerald-700">{t.ticketId}</span>
                      <span className="bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full text-[10px]">
                        {t.status}
                      </span>
                    </div>
                    <div className="text-slate-700">
                      <strong>Student:</strong> {t.studentName} ({t.targetGrade}) • <strong>Topic:</strong> {t.topic}
                    </div>
                    <div className="text-slate-500 text-[11px] leading-relaxed">
                      "{t.message}"
                    </div>
                    <div className="pt-1.5 border-t border-slate-200/80 flex items-center justify-between text-[10px] text-slate-400">
                      <span>Submitted: {t.timestamp}</span>
                      <button
                        type="button"
                        onClick={() => handleDownloadTicketReceipt(t)}
                        className="text-emerald-700 font-bold hover:underline inline-flex items-center gap-1"
                        title="Download official receipt as .txt file"
                      >
                        <FileDown className="w-3 h-3" />
                        <span>Download Receipt (.txt)</span>
                      </button>
                    </div>
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => setShowInquiryHistory(false)}
                  className="w-full bg-slate-200 hover:bg-slate-300 text-slate-800 font-semibold py-2 rounded-xl transition text-xs"
                >
                  Submit Another Inquiry
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmitInquiry} className="mt-4 space-y-3.5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Parent / Guardian Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={inquiryParentName}
                    onChange={(e) => setInquiryParentName(e.target.value)}
                    placeholder="e.g. Mr. Rajesh Sharma / Mrs. Gupta"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2 text-sm text-slate-900 focus:outline-none focus:border-emerald-600 focus:bg-white"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Student Name (Optional)
                    </label>
                    <input
                      type="text"
                      value={inquiryStudentName}
                      onChange={(e) => setInquiryStudentName(e.target.value)}
                      placeholder="e.g. Aarav"
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2 text-sm text-slate-900 focus:outline-none focus:border-emerald-600 focus:bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Target Grade / Class
                    </label>
                    <select
                      value={inquiryGrade}
                      onChange={(e) => setInquiryGrade(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2 text-sm text-slate-900 focus:outline-none focus:border-emerald-600 focus:bg-white"
                    >
                      <option value="Pre-Kindergarten">Pre-Kindergarten (Age 3+)</option>
                      <option value="Kindergarten">Kindergarten (Age 4-5)</option>
                      <option value="Grade 1">Grade 1</option>
                      <option value="Grade 2 to 5">Primary (Grades 2 to 5)</option>
                      <option value="Grade 6 to 8">Middle School (Grades 6 to 8)</option>
                      <option value="Grade 9 to 10">Secondary (Grades 9 & 10)</option>
                      <option value="Grade 11 to 12">Senior Secondary (11 & 12)</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Contact Phone / Email *
                    </label>
                    <input
                      type="text"
                      required
                      value={inquiryContact}
                      onChange={(e) => setInquiryContact(e.target.value)}
                      placeholder="Phone or email address"
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2 text-sm text-slate-900 focus:outline-none focus:border-emerald-600 focus:bg-white"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                      Inquiry Topic
                    </label>
                    <select
                      value={inquiryTopic}
                      onChange={(e) => setInquiryTopic(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2 text-sm text-slate-900 focus:outline-none focus:border-emerald-600 focus:bg-white"
                    >
                      <option value="Admissions & Enrollment">Admissions & Enrollment</option>
                      <option value="Campus Tour Request">Campus Tour Request</option>
                      <option value="Athletics & 400m Track">Athletics & 400m Track</option>
                      <option value="Transportation & Bus Routes">Transportation & Bus Routes</option>
                      <option value="Hastinapur Excursion">Hastinapur Excursion</option>
                      <option value="General Question">General Question</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1">
                    Your Question / Inquiry Details *
                  </label>
                  <textarea
                    required
                    rows={3}
                    value={inquiryMessage}
                    onChange={(e) => setInquiryMessage(e.target.value)}
                    placeholder="Describe your inquiry, questions about fee structure, or preferred tour date..."
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2 text-sm text-slate-900 focus:outline-none focus:border-emerald-600 focus:bg-white resize-none"
                  />
                </div>

                <div className="flex items-center justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setIsInquiryModalOpen(false)}
                    className="px-4 py-2 rounded-xl border border-slate-300 text-slate-600 text-sm font-semibold hover:bg-slate-100 transition"
                  >
                    Cancel
                  </button>

                  <button
                    type="submit"
                    className="bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold px-6 py-2 rounded-xl shadow-md hover:shadow-lg transition flex items-center gap-2"
                  >
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Generate Ticket & Submit</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* ADD NOTIFICATION / NOTICE MODAL - STRICTLY VERIFIES ADMIN PASSWORD "gahlaut" */}
      {/* ========================================================================= */}
      {isModalOpen && (
        <div className="fixed inset-0 z-[9990] bg-slate-950/70 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-white rounded-t-3xl sm:rounded-3xl max-w-lg w-full p-5 sm:p-7 shadow-2xl border border-slate-200 relative max-h-[92vh] flex flex-col overflow-y-auto">
            {/* Mobile Drag Indicator */}
            <div className="sm:hidden flex justify-center pb-2">
              <div className="w-12 h-1 bg-slate-300 rounded-full" />
            </div>

            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center">
                  <KeyRound className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-['Playfair_Display',serif] text-xl font-bold text-slate-900">
                    Admin Notification Manager
                  </h3>
                  <p className="text-xs text-slate-500">
                    Admin verification required to post notifications & circulars
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* AI Rule Notice */}
            <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-2xl text-xs text-amber-900 leading-relaxed flex items-start gap-2">
              <Info className="w-4 h-4 text-amber-600 flex-shrink-0 mt-0.5" />
              <div>
                <strong>📌 AI Holiday Rule:</strong> यदि आप छुट्टी का नोटिफिकेशन जोड़ेंगे तो AI छुट्टी (Holiday) की पुष्टि करेगा। यदि कोई छुट्टी का नोटिफिकेशन नहीं होगा तो AI स्पष्ट कहेगा कि <b>School is OPEN (स्कूल खुला है)</b>!
              </div>
            </div>

            {/* Form */}
            <form onSubmit={handlePublishNotice} className="mt-4 space-y-4">
              {/* Notice Title */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Notification Title (शीर्षक) *
                </label>
                <input
                  type="text"
                  required
                  value={modalTitle}
                  onChange={(e) => setModalTitle(e.target.value)}
                  placeholder="उदा. Urgent Notice: Heavy Rain Alert / Tomorrow School Closed"
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm text-slate-900 focus:outline-none focus:border-indigo-600 focus:bg-white transition"
                />
              </div>

              {/* Category & Date Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Category (प्रकार)
                  </label>
                  <select
                    value={modalCategory}
                    onChange={(e) => setModalCategory(e.target.value as any)}
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm text-slate-900 focus:outline-none focus:border-indigo-600 focus:bg-white transition"
                  >
                    <option value="holiday">Holiday / छुट्टी (Leave)</option>
                    <option value="exam">Exam / परीक्षा</option>
                    <option value="event">Event / खेलकूद / टूर</option>
                    <option value="general">General / सामान्य</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Effective Day / Date
                  </label>
                  <input
                    type="text"
                    value={modalDate}
                    onChange={(e) => setModalDate(e.target.value)}
                    placeholder="उदा. Tomorrow / कल"
                    className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm text-slate-900 focus:outline-none focus:border-indigo-600 focus:bg-white transition"
                  />
                </div>
              </div>

              {/* Notice Content */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Notification Details (विवरण) *
                </label>
                <textarea
                  required
                  rows={3}
                  value={modalContent}
                  onChange={(e) => setModalContent(e.target.value)}
                  placeholder="उदा. भारी बारिश के कारण कल स्कूल में अवकाश घोषित किया गया है..."
                  className="w-full bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-sm text-slate-900 focus:outline-none focus:border-indigo-600 focus:bg-white transition resize-none"
                />
              </div>

              {/* Notice Test / Banner Image Attachment (Optional) */}
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5 flex items-center justify-between">
                  <span className="flex items-center gap-1.5">
                    <ImageIcon className="w-3.5 h-3.5 text-indigo-600" />
                    <span>Attach Notice Image (Optional Test / Circular Image)</span>
                  </span>
                  <span className="text-[10px] text-slate-400 font-normal">File or URL</span>
                </label>

                <div className="flex gap-2">
                  <input
                    type="text"
                    value={modalNoticeImageUrl}
                    onChange={(e) => setModalNoticeImageUrl(e.target.value)}
                    placeholder="Paste image URL (https://...) or choose file..."
                    className="flex-1 bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 text-xs text-slate-900 focus:outline-none focus:border-indigo-600 focus:bg-white"
                  />
                  <label className="bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold px-3 py-2 rounded-xl text-xs flex items-center gap-1.5 cursor-pointer transition border border-slate-300 flex-shrink-0">
                    <Upload className="w-3.5 h-3.5 text-slate-600" />
                    <span>Browse</span>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) {
                          const reader = new FileReader();
                          reader.onload = (evt) => setModalNoticeImageUrl(evt.target?.result as string);
                          reader.readAsDataURL(file);
                        }
                      }}
                    />
                  </label>
                </div>

                {modalNoticeImageUrl && (
                  <div className="mt-2 relative rounded-xl overflow-hidden border border-slate-200 h-24 bg-slate-950 flex items-center justify-center">
                    <img src={modalNoticeImageUrl} alt="Notice Preview" className="max-h-full max-w-full object-contain" />
                    <button
                      type="button"
                      onClick={() => setModalNoticeImageUrl('')}
                      className="absolute top-1.5 right-1.5 bg-red-600 hover:bg-red-700 text-white rounded-full p-1 text-xs shadow"
                      title="Remove image"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                )}
              </div>

              {/* Admin Password Authentication */}
              <div className="pt-2 border-t border-slate-100">
                <label className="block text-xs font-bold text-red-700 uppercase tracking-wider mb-1.5 flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-red-600" />
                  <span>Admin Password (एडमिन सुरक्षा पासवर्ड) *</span>
                </label>

                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={modalPassword}
                    onChange={(e) => {
                      setModalPassword(e.target.value);
                      if (passwordError) setPasswordError('');
                    }}
                    placeholder="Enter private admin password..."
                    className={`w-full bg-slate-50 border rounded-xl px-3.5 py-2.5 text-sm text-slate-900 pr-10 focus:outline-none transition ${
                      passwordError
                        ? 'border-red-500 bg-red-50/30'
                        : isValidAdminPassword(modalPassword)
                        ? 'border-emerald-500 bg-emerald-50/20'
                        : 'border-slate-300 focus:border-indigo-600 focus:bg-white'
                    }`}
                  />

                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>

                {/* Password Error Message */}
                {passwordError && (
                  <p className="text-red-600 text-xs mt-1.5 font-medium flex items-center gap-1.5 animate-in fade-in duration-150">
                    <AlertCircle className="w-3.5 h-3.5 flex-shrink-0" />
                    <span>{passwordError}</span>
                  </p>
                )}

                {/* Password Success Match Hint */}
                {isValidAdminPassword(modalPassword) && !passwordError && (
                  <p className="text-emerald-600 text-xs mt-1.5 font-medium flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>पासवर्ड सत्यापित (Admin Password Verified)</span>
                  </p>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-600 text-sm font-semibold hover:bg-slate-100 transition"
                >
                  Cancel (रद्द करें)
                </button>

                <button
                  type="submit"
                  className="bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-bold px-6 py-2.5 rounded-xl shadow-md hover:shadow-lg transition flex items-center gap-2"
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span>Publish Notification (नोटिफिकेशन जारी करें)</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* DOWNLOAD CENTER MODAL (DOWNLOAD OFFLINE PORTAL, PROSPECTUS, NOTICES)      */}
      {/* ========================================================================= */}
      {isDownloadModalOpen && (
        <div className="fixed inset-0 z-[9992] bg-slate-950/75 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-white rounded-t-3xl sm:rounded-3xl max-w-2xl w-full p-5 sm:p-7 shadow-2xl border border-slate-200 relative max-h-[92vh] flex flex-col overflow-y-auto">
            {/* Mobile Drag Indicator */}
            <div className="sm:hidden flex justify-center pb-2">
              <div className="w-12 h-1 bg-slate-300 rounded-full" />
            </div>

            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-sky-50 text-sky-600 flex items-center justify-center border border-sky-200 shadow-sm">
                  <DownloadCloud className="w-6 h-6 animate-bounce" />
                </div>
                <div>
                  <h3 className="font-['Playfair_Display',serif] text-xl sm:text-2xl font-bold text-slate-900">
                    Download Files & Offline Portal
                  </h3>
                  <p className="text-xs text-slate-500">
                    डाउनलोड केंद्र: ऑफ़लाइन पोर्टल, स्कूल प्रॉस्पेक्टस व परिपत्र (Offline App & Files)
                  </p>
                </div>
              </div>

              <button
                onClick={() => setIsDownloadModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition"
                title="Close Download Center"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Content List */}
            <div className="mt-5 space-y-4 overflow-y-auto pr-1 text-sm">
              {/* Option 1: Standalone Offline Single-File HTML Portal */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-sky-50 via-slate-50 to-blue-50 border border-sky-200 shadow-sm relative overflow-hidden">
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="bg-sky-600 text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                        ⭐ Primary Download
                      </span>
                      <span className="text-[11px] font-bold text-slate-500">
                        100% Offline Standalone (.html)
                      </span>
                    </div>
                    <h4 className="font-bold text-base text-slate-900 flex items-center gap-2">
                      <span>NJS Public School Offline Web Portal</span>
                    </h4>
                    <p className="text-xs text-slate-600 leading-relaxed max-w-lg">
                      Complete single-file HTML version (~49 KB) of the official portal. Runs on any phone, tablet, or PC browser without needing internet or any server! Includes emergency holiday checker, admin notice publisher, sports track info, and photos.
                    </p>
                  </div>
                </div>

                <div className="mt-3.5 pt-3 border-t border-sky-200/80 flex flex-wrap items-center gap-2.5">
                  <button
                    onClick={() => handleDownloadOfflinePortal(false)}
                    className="bg-sky-600 hover:bg-sky-700 text-white font-bold text-xs sm:text-sm px-4 py-2.5 rounded-xl shadow-md hover:shadow-lg transition flex items-center gap-2"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Portal File (.html)</span>
                  </button>

                  <button
                    onClick={() => handleDownloadOfflinePortal(true)}
                    className="bg-white hover:bg-sky-50 text-sky-800 border border-sky-300 font-semibold text-xs sm:text-sm px-3.5 py-2.5 rounded-xl transition flex items-center gap-1.5"
                    title="Bundles your current notices into the downloaded offline file"
                  >
                    <FileDown className="w-4 h-4 text-sky-600" />
                    <span>Download Snapshot (with your active notices)</span>
                  </button>
                </div>
              </div>

              {/* Option 2: Official School Prospectus */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-50 border border-slate-200 hover:border-emerald-300 transition shadow-sm">
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="bg-emerald-600 text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                        Academic Guide
                      </span>
                      <span className="text-[11px] font-bold text-slate-500">
                        Printable / PDF Ready
                      </span>
                    </div>
                    <h4 className="font-bold text-base text-slate-900">
                      Official Prospectus & Admission Brochure 2026–2027
                    </h4>
                    <p className="text-xs text-slate-600 leading-relaxed max-w-lg">
                      Official school brochure with curriculum details (Pre-K to 12th), 400m Olympic athletic track specifications, historic Hastinapur tour itineraries, pottery arts, and admissions guidelines.
                    </p>
                  </div>
                </div>

                <div className="mt-3.5 pt-3 border-t border-slate-200 flex flex-wrap items-center gap-2.5">
                  <button
                    onClick={handleDownloadProspectus}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm px-4 py-2 rounded-xl shadow hover:shadow-md transition flex items-center gap-2"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Prospectus (.html)</span>
                  </button>

                  <a
                    href="/public/NJS_Public_School_Prospectus.html"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 font-semibold text-xs sm:text-sm px-3.5 py-2 rounded-xl transition flex items-center gap-1.5"
                  >
                    <Printer className="w-4 h-4 text-emerald-600" />
                    <span>Open & Print / Save as PDF</span>
                  </a>
                </div>
              </div>

              {/* Option 3: Circulars & Notices Bulletins */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-50 border border-slate-200 hover:border-indigo-300 transition shadow-sm">
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="bg-indigo-600 text-white text-[10px] font-bold px-2.5 py-0.5 rounded-full uppercase tracking-wider">
                        Notices Bulletin
                      </span>
                      <span className="text-[11px] font-bold text-slate-500">
                        {notices.length} active notices
                      </span>
                    </div>
                    <h4 className="font-bold text-base text-slate-900">
                      Current School Circulars & Holiday Bulletin
                    </h4>
                    <p className="text-xs text-slate-600 leading-relaxed max-w-lg">
                      Export currently active circulars, holiday announcements, and exam schedules issued by administration.
                    </p>
                  </div>
                </div>

                <div className="mt-3.5 pt-3 border-t border-slate-200 flex flex-wrap items-center gap-2.5">
                  <button
                    onClick={handleDownloadNoticesText}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs sm:text-sm px-4 py-2 rounded-xl shadow hover:shadow-md transition flex items-center gap-2"
                  >
                    <FileDown className="w-4 h-4" />
                    <span>Download Circulars (.txt)</span>
                  </button>

                  <button
                    onClick={handleDownloadNoticesJSON}
                    className="bg-white hover:bg-slate-100 text-slate-700 border border-slate-300 font-semibold text-xs sm:text-sm px-3.5 py-2 rounded-xl transition flex items-center gap-1.5"
                  >
                    <span>Export Data (.json)</span>
                  </button>
                </div>
              </div>

              {/* Option 4: Inquiry Tickets Export (if any) */}
              {submittedTickets.length > 0 && (
                <div className="p-4 sm:p-5 rounded-2xl bg-amber-50/60 border border-amber-200 shadow-sm">
                  <div className="flex justify-between items-start gap-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="bg-amber-600 text-white text-[10px] font-bold px-2 py-0.5 rounded-full uppercase">
                          Inquiry Records
                        </span>
                        <span className="text-[11px] font-bold text-slate-500">
                          {submittedTickets.length} tickets
                        </span>
                      </div>
                      <h4 className="font-bold text-sm text-slate-900 mt-1">
                        Parent Inquiry & Callback Tickets
                      </h4>
                      <p className="text-xs text-slate-600 mt-0.5">
                        Download registered tickets and student admissions inquiry reference numbers.
                      </p>
                    </div>

                    <button
                      onClick={handleDownloadTicketsCSV}
                      className="bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs px-3.5 py-2 rounded-xl shadow transition flex items-center gap-1.5 flex-shrink-0"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download (.csv)</span>
                    </button>
                  </div>
                </div>
              )}

              {/* Offline Instructions Box */}
              <div className="p-3.5 bg-slate-100 rounded-xl border border-slate-200 text-xs text-slate-600 space-y-1">
                <div className="font-bold text-slate-800 flex items-center gap-1.5">
                  <Info className="w-4 h-4 text-sky-600" />
                  <span>फ़ाइल का उपयोग कैसे करें (How to open downloaded files):</span>
                </div>
                <p>
                  1. <b>Download Portal File (.html)</b> पर क्लिक करें।
                </p>
                <p>
                  2. डाउनलोड होने के बाद अपने फोन या कंप्यूटर के Downloads फोल्डर में जाएं।
                </p>
                <p>
                  3. फ़ाइल पर डबल-क्लिक करें — यह बिना इंटरनेट (Offline) के किसी भी ब्राउज़र में तुरंत खुल जाएगी!
                </p>
              </div>

              {/* Bottom Official Link Box */}
              <div className="p-3 bg-slate-900 rounded-xl text-xs text-slate-300 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-2 text-center sm:text-left">
                <span className="text-slate-400 font-medium">Official Repository & Source:</span>
                <a
                  href="https://seemaanantom-eng.github.io/NJSpublicSchool/"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-emerald-400 hover:text-emerald-300 font-bold underline break-all inline-flex items-center gap-1"
                >
                  <span>https://seemaanantom-eng.github.io/NJSpublicSchool/</span>
                  <ExternalLink className="w-3.5 h-3.5 flex-shrink-0" />
                </a>
              </div>
            </div>

            {/* Modal Footer */}
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
              <span className="text-[11px] text-slate-400">
                Official Web: seemaanantom-eng.github.io/NJSpublicSchool
              </span>
              <button
                type="button"
                onClick={() => setIsDownloadModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold transition"
              >
                Close (बंद करें)
              </button>
            </div>
          </div>
        </div>
      )}
      {/* ========================================================================= */}
      {/* 🧪 ADD ANY IMAGE FOR TEST MODAL (Upload, Presets, Filters, Sandbox)      */}
      {/* ========================================================================= */}
      {isTestImageModalOpen && (
        <div className="fixed inset-0 z-[9994] bg-slate-950/80 backdrop-blur-sm flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto animate-in fade-in duration-200">
          <div className="bg-white rounded-t-3xl sm:rounded-3xl max-w-2xl w-full p-5 sm:p-7 shadow-2xl border border-slate-200 relative max-h-[92vh] flex flex-col overflow-y-auto">
            {/* Mobile Drag Handle */}
            <div className="sm:hidden flex justify-center pb-2">
              <div className="w-12 h-1 bg-slate-300 rounded-full" />
            </div>

            {/* Modal Header */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-11 h-11 rounded-2xl bg-amber-50 text-amber-700 flex items-center justify-center border border-amber-200 shadow-sm">
                  <ImagePlus className="w-6 h-6 text-amber-600" />
                </div>
                <div>
                  <h3 className="font-['Playfair_Display',serif] text-xl sm:text-2xl font-bold text-slate-900 flex items-center gap-2">
                    <span>Add Any Image for Test</span>
                    <span className="bg-amber-100 text-amber-800 text-[11px] font-mono px-2 py-0.5 rounded-full uppercase font-bold">
                      Sandbox
                    </span>
                  </h3>
                  <p className="text-xs text-slate-500">
                    छवि परीक्षण: अपनी पसंद की कोई भी फोटो अपलोड करें या URL जोड़कर साइट पर टेस्ट करें
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setIsTestImageModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Tabs for Image Input Source */}
            <div className="mt-4 flex gap-2 p-1 bg-slate-100 rounded-2xl text-xs font-bold text-slate-700">
              <button
                type="button"
                onClick={() => setTestImageSourceType('upload')}
                className={`flex-1 py-2 px-3 rounded-xl transition flex items-center justify-center gap-1.5 ${
                  testImageSourceType === 'upload'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Upload className="w-4 h-4 text-emerald-600" />
                <span>Upload File</span>
              </button>

              <button
                type="button"
                onClick={() => setTestImageSourceType('url')}
                className={`flex-1 py-2 px-3 rounded-xl transition flex items-center justify-center gap-1.5 ${
                  testImageSourceType === 'url'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Globe className="w-4 h-4 text-sky-600" />
                <span>Paste Image URL</span>
              </button>

              <button
                type="button"
                onClick={() => setTestImageSourceType('sample')}
                className={`flex-1 py-2 px-3 rounded-xl transition flex items-center justify-center gap-1.5 ${
                  testImageSourceType === 'sample'
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Sparkles className="w-4 h-4 text-amber-600" />
                <span>Sample Presets</span>
              </button>
            </div>

            {/* Tab 1: File Upload */}
            {testImageSourceType === 'upload' && (
              <div className="mt-4">
                <label className="border-2 border-dashed border-amber-300 hover:border-amber-500 bg-amber-50/40 hover:bg-amber-50/70 transition rounded-2xl p-6 flex flex-col items-center justify-center cursor-pointer text-center group">
                  <div className="w-14 h-14 rounded-full bg-amber-100 group-hover:bg-amber-200 text-amber-700 flex items-center justify-center mb-3 transition shadow-sm">
                    <Camera className="w-7 h-7" />
                  </div>
                  <span className="text-sm font-bold text-slate-800">
                    Click to browse or drag & drop any image
                  </span>
                  <span className="text-xs text-slate-500 mt-1">
                    Supports JPG, PNG, WebP, GIF, SVG (Up to 15 MB)
                  </span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleImageFileUpload}
                    className="hidden"
                  />
                </label>
              </div>
            )}

            {/* Tab 2: URL Input */}
            {testImageSourceType === 'url' && (
              <div className="mt-4 space-y-2">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Direct Image URL (वेब छवि लिंक)
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={testImageUrl}
                    onChange={(e) => {
                      setTestImageUrl(e.target.value);
                      if (!testImageTitle) setTestImageTitle('Web Test Image');
                    }}
                    placeholder="https://example.com/photo.jpg"
                    className="flex-1 bg-slate-50 border border-slate-300 rounded-xl px-3.5 py-2.5 text-xs sm:text-sm text-slate-900 focus:outline-none focus:border-amber-500 focus:bg-white"
                  />
                  {testImageUrl && (
                    <button
                      type="button"
                      onClick={() => setTestImageUrl('')}
                      className="bg-slate-200 hover:bg-slate-300 text-slate-700 px-3 py-2 rounded-xl text-xs font-semibold"
                    >
                      Clear
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Tab 3: Sample High-Res Presets */}
            {testImageSourceType === 'sample' && (
              <div className="mt-4 space-y-2">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Select a High-Res School Sample Preset
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 max-h-48 overflow-y-auto pr-1">
                  {SAMPLE_TEST_IMAGES.map((sample) => (
                    <button
                      key={sample.id}
                      type="button"
                      onClick={() => handleSelectSampleImage(sample)}
                      className={`text-left p-2.5 rounded-xl border transition flex items-center gap-3 ${
                        testImageUrl === sample.url
                          ? 'bg-amber-50 border-amber-500 shadow-sm'
                          : 'bg-slate-50 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <img
                        src={sample.url}
                        alt={sample.label}
                        className="w-12 h-12 rounded-lg object-cover flex-shrink-0"
                      />
                      <div className="overflow-hidden">
                        <div className="text-xs font-bold text-slate-900 truncate">
                          {sample.label}
                        </div>
                        <div className="text-[10px] text-slate-500 truncate">
                          {sample.title}
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {/* Live Interactive Preview Sandbox */}
            {testImageUrl ? (
              <div className="mt-5 p-4 rounded-2xl bg-slate-900 text-white space-y-3.5">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-amber-400 flex items-center gap-1.5 uppercase tracking-wider">
                    <Sparkles className="w-3.5 h-3.5" /> Live Sandbox Preview
                  </span>
                  <div className="flex items-center gap-2 font-mono text-[11px] text-slate-400">
                    {testImageDimensions && (
                      <span>{testImageDimensions.width}×{testImageDimensions.height}px</span>
                    )}
                    {testImageFileSize && <span>• {testImageFileSize}</span>}
                  </div>
                </div>

                {/* Aspect-Ratio Preview Frame */}
                <div
                  className={`relative overflow-hidden rounded-xl bg-slate-950 flex items-center justify-center border border-slate-800 transition-all ${
                    testImageAspect === 'tall'
                      ? 'aspect-[9/12] max-h-64'
                      : testImageAspect === 'wide'
                      ? 'aspect-[21/9] max-h-56'
                      : testImageAspect === 'square'
                      ? 'aspect-square max-h-60'
                      : 'aspect-[16/10] max-h-60'
                  }`}
                >
                  <img
                    src={testImageUrl}
                    alt="Preview"
                    className={`w-full h-full object-cover transition-all duration-300 ${
                      testImageFilter === 'vivid'
                        ? 'contrast-125 saturate-150'
                        : testImageFilter === 'grayscale'
                        ? 'grayscale'
                        : testImageFilter === 'warm'
                        ? 'sepia-[0.35] saturate-125'
                        : testImageFilter === 'cool'
                        ? 'hue-rotate-180 saturate-110'
                        : ''
                    }`}
                  />
                  <div className="absolute top-2 left-2 bg-amber-500 text-slate-950 font-extrabold text-[9px] uppercase px-2 py-0.5 rounded-full shadow">
                    🧪 TEST PREVIEW
                  </div>
                </div>

                {/* Aspect Ratio Test Controls */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                    Aspect Ratio Fit (पहलू अनुपात परीक्षण):
                  </label>
                  <div className="grid grid-cols-4 gap-1.5 text-xs">
                    {(['normal', 'tall', 'wide', 'square'] as const).map((asp) => (
                      <button
                        key={asp}
                        type="button"
                        onClick={() => setTestImageAspect(asp)}
                        className={`py-1.5 px-2 rounded-lg font-semibold capitalize transition text-center ${
                          testImageAspect === asp
                            ? 'bg-amber-500 text-slate-950 font-bold'
                            : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                        }`}
                      >
                        {asp}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Filter Test Controls */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                    Color Filter Test (रंग फ़िल्टर परीक्षण):
                  </label>
                  <div className="grid grid-cols-5 gap-1.5 text-xs">
                    {(['none', 'vivid', 'grayscale', 'warm', 'cool'] as const).map((flt) => (
                      <button
                        key={flt}
                        type="button"
                        onClick={() => setTestImageFilter(flt)}
                        className={`py-1.5 px-1 rounded-lg font-semibold capitalize transition text-center text-[11px] ${
                          testImageFilter === flt
                            ? 'bg-emerald-500 text-white font-bold'
                            : 'bg-slate-800 text-slate-300 hover:bg-slate-700'
                        }`}
                      >
                        {flt}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Target Destination Selector */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1.5">
                    Where to Apply Image (छवि कहाँ लागू करें):
                  </label>
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2 text-xs">
                    <button
                      type="button"
                      onClick={() => setTestImageTarget('notice-board')}
                      className={`p-2.5 rounded-xl border text-left transition ${
                        testImageTarget === 'notice-board'
                          ? 'bg-amber-500/25 border-amber-400 text-amber-300 font-extrabold ring-1 ring-amber-400'
                          : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700/60'
                      }`}
                    >
                      <div className="font-extrabold flex items-center gap-1 text-amber-400">
                        <FlaskConical className="w-3.5 h-3.5" /> Notice Box Test
                      </div>
                      <div className="text-[10px] text-slate-300 mt-0.5">Bottom of circulars</div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setTestImageTarget('gallery')}
                      className={`p-2.5 rounded-xl border text-left transition ${
                        testImageTarget === 'gallery'
                          ? 'bg-amber-500/25 border-amber-400 text-amber-300 font-bold ring-1 ring-amber-400'
                          : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700/60'
                      }`}
                    >
                      <div className="font-bold">🖼️ Gallery Grid</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">Community moments</div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setTestImageTarget('hero')}
                      className={`p-2.5 rounded-xl border text-left transition ${
                        testImageTarget === 'hero'
                          ? 'bg-amber-500/25 border-amber-400 text-amber-300 font-bold ring-1 ring-amber-400'
                          : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700/60'
                      }`}
                    >
                      <div className="font-bold">🌟 Hero Banner</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">Top page cover</div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setTestImageTarget('logo')}
                      className={`p-2.5 rounded-xl border text-left transition ${
                        testImageTarget === 'logo'
                          ? 'bg-amber-500/25 border-amber-400 text-amber-300 font-bold ring-1 ring-amber-400'
                          : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700/60'
                      }`}
                    >
                      <div className="font-bold">🍎 School Emblem</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">Logo replacement</div>
                    </button>

                    <button
                      type="button"
                      onClick={() => setTestImageTarget('all')}
                      className={`p-2.5 rounded-xl border text-left transition col-span-2 sm:col-span-1 ${
                        testImageTarget === 'all'
                          ? 'bg-amber-500/25 border-amber-400 text-amber-300 font-bold ring-1 ring-amber-400'
                          : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700/60'
                      }`}
                    >
                      <div className="font-bold">✨ Everywhere</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">All sections</div>
                    </button>
                  </div>
                </div>

                {/* Title & Description Fields */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 pt-1">
                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 mb-1">
                      Photo Title (शीर्षक)
                    </label>
                    <input
                      type="text"
                      value={testImageTitle}
                      onChange={(e) => setTestImageTitle(e.target.value)}
                      placeholder="e.g. Science Exhibition 2026"
                      className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-bold text-slate-300 mb-1">
                      Caption / Subtitle (उपशीर्षक)
                    </label>
                    <input
                      type="text"
                      value={testImageSubtitle}
                      onChange={(e) => setTestImageSubtitle(e.target.value)}
                      placeholder="e.g. Student lab experimentation"
                      className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400"
                    />
                  </div>
                </div>
              </div>
            ) : (
              <div className="mt-4 p-4 rounded-xl bg-slate-50 border border-slate-200 text-center text-xs text-slate-500">
                👆 ऊपर फ़ाइल चुनें, URL डालें, या कोई नमूना छवि चुनें। (Choose an image to preview)
              </div>
            )}

            {/* ADMIN PASSWORD REQUIREMENT TO UPLOAD / APPLY IMAGE */}
            <div className="mt-4 p-4 rounded-2xl bg-amber-50 border-2 border-amber-400 shadow-sm">
              <label className="block text-xs font-bold text-slate-900 mb-1.5 flex items-center gap-1.5">
                <Lock className="w-4 h-4 text-amber-700" />
                <span>Admin Password Required to Upload / Apply Image (छवि अपलोड करने हेतु एडमिन पासवर्ड): *</span>
              </label>
              <div className="relative">
                <input
                  type={showUploadImagePassword ? 'text' : 'password'}
                  value={uploadImagePassword}
                  onChange={(e) => {
                    setUploadImagePassword(e.target.value);
                    if (uploadImagePasswordError) setUploadImagePasswordError('');
                  }}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && testImageUrl.trim()) {
                      e.preventDefault();
                      handleAddTestImage();
                    }
                  }}
                  placeholder="Enter private admin password..."
                  className={`w-full bg-white border rounded-xl px-3.5 py-2.5 pr-10 text-xs sm:text-sm text-slate-900 font-mono shadow-inner focus:outline-none transition ${
                    uploadImagePasswordError
                      ? 'border-red-500 bg-red-50/20'
                      : isValidAdminPassword(uploadImagePassword)
                      ? 'border-emerald-500 bg-emerald-50/20'
                      : 'border-slate-300 focus:border-amber-500'
                  }`}
                />
                <button
                  type="button"
                  onClick={() => setShowUploadImagePassword(!showUploadImagePassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
                >
                  {showUploadImagePassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>

              {uploadImagePasswordError ? (
                <p className="text-xs text-red-600 font-bold mt-2 flex items-center gap-1.5 animate-in fade-in">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  <span>{uploadImagePasswordError}</span>
                </p>
              ) : (
                <div className="flex items-center justify-between text-[11px] text-slate-600 mt-1.5">
                  <span>🔒 Protected by Admin Password Authorization</span>
                  {isValidAdminPassword(uploadImagePassword) && (
                    <span className="text-emerald-700 font-bold flex items-center gap-1">
                      <Check className="w-3.5 h-3.5" /> Password Verified
                    </span>
                  )}
                </div>
              )}
            </div>

            {/* Modal Actions */}
            <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={() => {
                  setUploadImagePasswordError('');
                  setIsTestImageModalOpen(false);
                }}
                className="px-4 py-2.5 rounded-xl border border-slate-300 text-slate-600 text-xs sm:text-sm font-semibold hover:bg-slate-100 transition"
              >
                Cancel (रद्द करें)
              </button>

              <button
                type="button"
                onClick={handleAddTestImage}
                disabled={!testImageUrl.trim()}
                className="bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-slate-950 text-xs sm:text-sm font-bold px-6 py-2.5 rounded-xl shadow-md hover:shadow-lg transition flex items-center gap-2 cursor-pointer disabled:cursor-not-allowed"
              >
                <CheckCircle2 className="w-4 h-4 text-slate-950" />
                <span>Upload & Apply Image (पासवर्ड से जोड़ें)</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 🔍 FULL RESOLUTION PHOTO LIGHTBOX MODAL                                   */}
      {/* ========================================================================= */}
      {lightboxPhoto && (
        <div
          className="fixed inset-0 z-[9999] bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-3 sm:p-6 animate-in fade-in duration-150"
          onClick={() => setLightboxPhoto(null)}
        >
          <div
            className="relative max-w-4xl w-full bg-slate-900 rounded-3xl overflow-hidden shadow-2xl border border-slate-800 flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Top Bar */}
            <div className="p-4 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-white font-bold text-sm sm:text-base">
                  {lightboxPhoto.title}
                </span>
                {lightboxPhoto.isTest && (
                  <span className="bg-amber-500 text-slate-950 text-[10px] font-extrabold px-2 py-0.5 rounded-full uppercase">
                    🧪 TEST PHOTO
                  </span>
                )}
              </div>

              <div className="flex items-center gap-2">
                {lightboxPhoto.isTest && (
                  <button
                    type="button"
                    onClick={() => handleRemovePhoto(lightboxPhoto.id, lightboxPhoto.title)}
                    className="bg-red-600/80 hover:bg-red-600 text-white text-xs font-semibold px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition"
                    title="Delete this test photo"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete Photo</span>
                  </button>
                )}

                <button
                  type="button"
                  onClick={() => {
                    updateNoticeBoxTestImageStateAndServer(lightboxPhoto.url, lightboxPhoto.title);
                    setSuccessToast(`✅ Notice Box Test Image set to: "${lightboxPhoto.title}" (Saved to Cloud)`);
                    setTimeout(() => setSuccessToast(''), 4000);
                    setLightboxPhoto(null);
                    setTimeout(() => {
                      const el = document.getElementById('notices');
                      if (el) el.scrollIntoView({ behavior: 'smooth' });
                    }, 250);
                  }}
                  className="bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-bold px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition shadow-sm cursor-pointer"
                  title="Make this photo the Notice Box Test Image (सूचना पट्ट में लगाएं)"
                >
                  <FlaskConical className="w-3.5 h-3.5 text-slate-950" />
                  <span>Make Notice Box Test Image</span>
                </button>

                <a
                  href={lightboxPhoto.url}
                  download={`NJS_School_${lightboxPhoto.title.replace(/\s+/g, '_')}.jpg`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold px-3 py-1.5 rounded-xl flex items-center gap-1.5 transition"
                  title="Download Image"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download</span>
                </a>

                <button
                  type="button"
                  onClick={() => setLightboxPhoto(null)}
                  className="text-slate-400 hover:text-white p-1.5 rounded-xl hover:bg-slate-800 transition"
                  title="Close Lightbox"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* High-Res Image Display */}
            <div className="relative bg-black flex items-center justify-center max-h-[70vh] overflow-hidden p-2">
              <img
                src={lightboxPhoto.url}
                alt={lightboxPhoto.title}
                className="max-h-[66vh] max-w-full object-contain rounded-lg shadow-2xl"
              />
            </div>

            {/* Subtitle / Footer info */}
            <div className="p-4 bg-slate-950 text-slate-300 text-xs flex flex-wrap justify-between items-center gap-2 border-t border-slate-800">
              <div>
                {lightboxPhoto.subtitle && (
                  <p className="text-slate-300 text-xs">{lightboxPhoto.subtitle}</p>
                )}
                {lightboxPhoto.dimensions && (
                  <span className="text-[10px] text-amber-300 font-mono mt-0.5 inline-block">
                    Resolution: {lightboxPhoto.dimensions} {lightboxPhoto.fileSize && `• Size: ${lightboxPhoto.fileSize}`}
                  </span>
                )}
              </div>

              <span className="text-[11px] text-slate-400 font-medium">
                NJS Public School Campus Archives
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
